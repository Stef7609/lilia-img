/* Lilia Studio 2 — Studio d'images et Canvas */
(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const L = window.LS, P = AI.PROVIDERS;
  const { esc, toast } = L;

  /* =================== Navigation entre espaces =================== */
  const main = $('#main');
  let view = 'chat';
  function setView(v) {
    view = v;
    document.querySelectorAll('#modes button').forEach(b => b.classList.toggle('on', b.dataset.view === v));
    main.classList.toggle('in-view', v !== 'chat');
    $('#view-images').hidden = v !== 'images';
    $('#view-canvas').hidden = v !== 'canvas';
    $('#top-title').style.visibility = v === 'chat' ? '' : 'hidden';
    if (v === 'images') Img.show();
    if (v === 'canvas') Cv.show();
    L.closeSide();
  }
  $('#modes').addEventListener('click', e => { const b = e.target.closest('[data-view]'); if (b) setView(b.dataset.view); });
  $('#btn-new').addEventListener('click', () => setView('chat'));
  $('#sessions').addEventListener('click', e => { if (e.target.closest('.it') && !e.target.closest('.del')) setView('chat'); });
  $('#cards').addEventListener('click', e => { const b = e.target.closest('[data-start]'); if (b && (b.dataset.start === 'images' || b.dataset.start === 'canvas')) setView(b.dataset.start); });
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n' && !e.shiftKey) setView('chat'); });

  /* =================== Base d'images (IndexedDB) =================== */
  const DB = {
    db: null,
    open() {
      if (this.db) return Promise.resolve(this.db);
      return new Promise((res, rej) => {
        const r = indexedDB.open('lilia-studio-2-images', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('images', { keyPath: 'id' });
        r.onsuccess = () => { this.db = r.result; res(this.db); };
        r.onerror = () => rej(r.error);
      });
    },
    async tx(mode, fn) { const db = await this.open(); return new Promise((res, rej) => { const t = db.transaction('images', mode); const s = t.objectStore('images'); const out = fn(s); t.oncomplete = () => res(out && out.result); t.onerror = () => rej(t.error); }); },
    all() { return this.tx('readonly', s => s.getAll()).then(l => (l || []).sort((a, b) => b.t - a.t)); },
    put(o) { return this.tx('readwrite', s => s.put(o)); },
    del(id) { return this.tx('readwrite', s => s.delete(id)); }
  };

  /* =================== Studio d'images =================== */
  const IMG_DEFAULTS = {
    gemini: [{ id: 'gemini-2.5-flash-image', name: 'Nano Banana (Gemini 2.5 Flash Image)' }],
    openai: [{ id: 'gpt-image-1', name: 'GPT Image 1' }],
    openrouter: [{ id: 'google/gemini-2.5-flash-image', name: 'Gemini Flash Image (via OpenRouter)' }],
    demo: [{ id: 'lilia-demo-image', name: 'Démo (image simulée, gratuite)' }]
  };
  const STYLES = [
    ['Photo réaliste', 'photographie réaliste, lumière naturelle, haute définition'],
    ['Illustration', 'illustration numérique soignée, couleurs riches'],
    ['3D', 'rendu 3D, matières réalistes, éclairage studio'],
    ['Logo', 'logo minimaliste vectoriel, fond uni, lisible en petit'],
    ['Affiche', "affiche graphique, composition forte, espace pour un titre"],
    ['Néon', 'ambiance néon cyberpunk, reflets, nuit'],
    ['Aquarelle', 'aquarelle douce, texture papier']
  ];
  const RATIOS = ['1:1', '16:9', '9:16', '4:3'];

  async function listImageModels(p) {
    const key = Store.keys[p];
    if (p === 'demo') return IMG_DEFAULTS.demo;
    if (!key) return [];
    const c = Store.modelCache(p + '-img');
    if (c && Date.now() - c.t < 864e5 && c.list.length) return c.list;
    let list = [];
    try {
      if (p === 'gemini') {
        const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { headers: { 'x-goog-api-key': key } });
        if (r.ok) list = (await r.json()).models.filter(m => /image/.test(m.name) && /gemini|banana/.test(m.name) && (m.supportedGenerationMethods || []).includes('generateContent'))
          .map(m => ({ id: m.name.replace('models/', ''), name: m.displayName || m.name }));
      } else if (p === 'openai') {
        const r = await fetch('https://api.openai.com/v1/models', { headers: { Authorization: 'Bearer ' + key } });
        if (r.ok) list = (await r.json()).data.map(m => m.id).filter(id => /^(gpt-image|dall-e-3)/.test(id)).sort().reverse().map(id => ({ id, name: id }));
      } else if (p === 'openrouter') {
        const r = await fetch('https://openrouter.ai/api/v1/models');
        if (r.ok) list = (await r.json()).data.filter(m => m.architecture && (m.architecture.output_modalities || []).includes('image')).map(m => ({ id: m.id, name: m.name || m.id }));
      }
    } catch (e) { console.warn('modèles image', p, e.message); }
    if (list.length) Store.modelCache(p + '-img', list);
    return list.length ? list : (IMG_DEFAULTS[p] || []);
  }

  const toBlob = dataUrl => fetch(dataUrl).then(r => r.blob());

  async function httpErr(r, name) {
    let m = ''; try { const j = await r.json(); m = (j.error && (j.error.message || j.error)) || JSON.stringify(j); } catch { m = r.statusText; }
    let hint = '';
    if (r.status === 429 || /quota|billing|free tier|limit: 0/i.test(m)) hint = "La création d'images est payante chez ce fournisseur : active la facturation (quelques dollars suffisent) ou choisis le modèle Démo. ";
    else if (r.status === 401 || r.status === 403) hint = 'Clé refusée : vérifie-la dans Réglages. ';
    return new Error(hint + `(${name} ${r.status}) ` + String(m).slice(0, 220));
  }

  async function generateImage({ model, prompt, ratio, refs, signal }) {
    const [p, id] = AI.split(model);
    const key = Store.keys[p];
    if (p === 'demo') return [await demoImage(prompt, ratio)];
    if (!key) throw new Error(`Ajoute ta clé ${P[p].short} dans Réglages.`);
    if (p === 'gemini') {
      const body = r => ({
        contents: [{ role: 'user', parts: [...refs.map(f => ({ inline_data: { mime_type: f.type, data: f.data.split(',')[1] } })), { text: prompt + (r ? '' : `\n\nFormat de l'image : ${ratio}.`) }] }],
        generationConfig: Object.assign({ responseModalities: ['TEXT', 'IMAGE'] }, r ? { imageConfig: { aspectRatio: ratio } } : {})
      });
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(id)}:generateContent`;
      const call = b => fetch(url, { method: 'POST', signal, headers: { 'content-type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(b) });
      let r = await call(body(true));
      if (r.status === 400) { const t = await r.clone().text(); if (/imageConfig|aspect/i.test(t)) r = await call(body(false)); }
      if (!r.ok) throw await httpErr(r, 'Gemini');
      const j = await r.json();
      const parts = (j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || [];
      const out = parts.map(x => x.inlineData || x.inline_data).filter(Boolean).map(d => `data:${d.mimeType || d.mime_type || 'image/png'};base64,${d.data}`);
      if (!out.length) { const txt = parts.map(x => x.text).filter(Boolean).join(' '); throw new Error('Aucune image reçue. ' + (txt || (j.promptFeedback ? 'Demande refusée par le filtre de sécurité.' : ''))); }
      return out;
    }
    if (p === 'openai') {
      const size = ratio === '1:1' ? '1024x1024' : ratio === '9:16' ? '1024x1536' : '1536x1024';
      const dalle = /dall-e/.test(id); const dSize = ratio === '1:1' ? '1024x1024' : ratio === '9:16' ? '1024x1792' : '1792x1024';
      let r;
      if (refs.length && !dalle) {
        const fd = new FormData(); fd.append('model', id); fd.append('prompt', prompt); fd.append('size', size);
        for (const f of refs) fd.append('image[]', await toBlob(f.data), f.name || 'ref.png');
        r = await fetch('https://api.openai.com/v1/images/edits', { method: 'POST', signal, headers: { Authorization: 'Bearer ' + key }, body: fd });
      } else {
        const b = { model: id, prompt, n: 1, size: dalle ? dSize : size }; if (dalle) b.response_format = 'b64_json';
        r = await fetch('https://api.openai.com/v1/images/generations', { method: 'POST', signal, headers: { 'content-type': 'application/json', Authorization: 'Bearer ' + key }, body: JSON.stringify(b) });
      }
      if (!r.ok) throw await httpErr(r, 'OpenAI');
      const j = await r.json();
      return j.data.map(d => d.b64_json ? 'data:image/png;base64,' + d.b64_json : d.url);
    }
    if (p === 'openrouter') {
      const content = [{ type: 'text', text: prompt }, ...refs.map(f => ({ type: 'image_url', image_url: { url: f.data } }))];
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST', signal, headers: { 'content-type': 'application/json', Authorization: 'Bearer ' + key, 'HTTP-Referer': location.origin, 'X-Title': 'Lilia Studio' },
        body: JSON.stringify({ model: id, messages: [{ role: 'user', content }], modalities: ['image', 'text'], image_config: { aspect_ratio: ratio } })
      });
      if (!r.ok) throw await httpErr(r, 'OpenRouter');
      const j = await r.json(); const m = j.choices && j.choices[0] && j.choices[0].message;
      const out = ((m && m.images) || []).map(x => x.image_url && x.image_url.url).filter(Boolean);
      if (!out.length) throw new Error('Aucune image reçue. ' + ((m && m.content) || ''));
      return out;
    }
    throw new Error('Ce fournisseur ne crée pas d\'images.');
  }

  // Image simulée (mode démo)
  const eye = new Image(); eye.src = 'img/eye.png';
  function demoImage(prompt, ratio) {
    const [rw, rh] = ratio.split(':').map(Number); const W = 1024, H = Math.round(W * rh / rw);
    const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
    let h = 0; for (const ch of prompt) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    const hue = h % 360;
    const g = x.createRadialGradient(W * .3, H * .3, 10, W * .5, H * .5, Math.max(W, H) * .8);
    g.addColorStop(0, `hsl(${hue},85%,55%)`); g.addColorStop(.5, `hsl(${(hue + 40) % 360},70%,25%)`); g.addColorStop(1, '#07070A');
    x.fillStyle = g; x.fillRect(0, 0, W, H);
    for (let i = 0; i < 40; i++) { x.fillStyle = `hsla(${(hue + i * 9) % 360},90%,70%,${((h >> (i % 24)) & 7) / 40})`; x.beginPath(); x.arc(((h * (i + 3)) % W), ((h * (i + 7)) % H), 20 + (i * 13) % 120, 0, 7); x.fill(); }
    if (eye.complete && eye.naturalWidth) { const s = Math.min(W, H) * .42; x.globalAlpha = .9; x.drawImage(eye, W / 2 - s / 2, H / 2 - s / 2 - s * .15, s, s * eye.naturalHeight / eye.naturalWidth); x.globalAlpha = 1; }
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = '600 34px I, sans-serif';
    const t = prompt.length > 60 ? prompt.slice(0, 58) + '…' : prompt; x.fillText(t, W / 2, H * .78);
    x.font = '22px JB, monospace'; x.fillStyle = '#FF2E50'; x.fillText('IMAGE DÉMO · LILIA STUDIO', W / 2, H * .78 + 44);
    return new Promise(r => setTimeout(() => r(c.toDataURL('image/jpeg', .9)), 900));
  }

  const Img = {
    built: false, refs: [], busy: null,
    async show() {
      if (!this.built) this.build();
      await this.fillModels(); this.renderGallery();
    },
    build() {
      this.built = true;
      const s = Store.settings;
      $('#view-images').innerHTML = `
        <div class="v-wrap">
          <div class="v-head"><span class="k">STUDIO D'IMAGES</span><h2>Crée et retouche <em>tes images</em></h2>
            <p class="hint">Décris l'image voulue. Ajoute une image de référence pour la retoucher ou t'en inspirer. <b>Création d'images : payante chez les fournisseurs</b> (environ 3 à 7 centimes l'image). Le modèle Démo est gratuit pour essayer. <a href="#" id="i-guide">En savoir plus</a></p></div>
          <div class="composer i-comp">
            <div class="attachments" id="i-refs"></div>
            <textarea id="i-prompt" rows="3" placeholder="Ex. un t-shirt GEN X avec une grenouille disco qui fait du roller, style rétro 80s"></textarea>
            <div class="i-styles">${STYLES.map(([n]) => `<button class="pill" data-style="${esc(n)}">${esc(n)}</button>`).join('')}</div>
            <div class="composer-row">
              <label class="pill">+ Image de référence<input type="file" id="i-file" accept="image/*" multiple hidden></label>
              <div class="seg" id="i-ratio">${RATIOS.map(r => `<button data-r="${r}" class="${(s.imgRatio || '1:1') === r ? 'on' : ''}">${r}</button>`).join('')}</div>
              <select class="inp i-model" id="i-model" aria-label="Modèle d'image"></select>
              <button class="btn" id="i-go">Générer</button>
            </div>
          </div>
          <div class="i-status" id="i-status"></div>
          <div class="lab" style="margin:22px 2px 10px">TA GALERIE</div>
          <div class="gallery" id="i-gal"></div>
        </div>`;
      $('#i-guide').onclick = e => { e.preventDefault(); L.openGuide(); };
      $('#i-ratio').onclick = e => { const b = e.target.closest('[data-r]'); if (!b) return; document.querySelectorAll('#i-ratio button').forEach(x => x.classList.toggle('on', x === b)); Store.saveSettings({ imgRatio: b.dataset.r }); };
      $('#i-model').onchange = e => Store.saveSettings({ imgModel: e.target.value });
      document.querySelectorAll('[data-style]').forEach(b => b.onclick = () => {
        const st = STYLES.find(x => x[0] === b.dataset.style)[1]; const t = $('#i-prompt');
        b.classList.toggle('on');
        t.value = b.classList.contains('on') ? (t.value.trim() ? t.value.trim() + ', ' : '') + st : t.value.replace(new RegExp(',?\\s*' + st.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')), '').trim();
      });
      $('#i-file').onchange = async e => { for (const f of e.target.files) await this.addRef(f); e.target.value = ''; };
      $('#i-refs').onclick = e => { const b = e.target.closest('[data-rm]'); if (b) { this.refs.splice(+b.dataset.rm, 1); this.drawRefs(); } };
      $('#i-prompt').addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) this.go(); });
      $('#i-prompt').addEventListener('paste', e => { const fl = [...(e.clipboardData.files || [])].filter(f => f.type.startsWith('image/')); if (fl.length) { e.preventDefault(); fl.forEach(f => this.addRef(f)); } });
      $('#i-go').onclick = () => this.go();
      $('#i-gal').onclick = e => { const c = e.target.closest('[data-id]'); if (c) this.open(c.dataset.id); };
    },
    async addRef(file) {
      const data = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
      this.refs.push({ name: file.name || 'ref.png', type: file.type || 'image/png', data: await shrink(data, 1536) }); this.drawRefs();
    },
    drawRefs() { $('#i-refs').innerHTML = this.refs.map((f, i) => `<span class="att-chip"><img src="${f.data}" alt=""><span>${esc(f.name)}</span><button data-rm="${i}" aria-label="Retirer">✕</button></span>`).join(''); },
    async fillModels() {
      const sel = $('#i-model'); const s = Store.settings;
      const groups = [];
      for (const p of ['gemini', 'openai', 'openrouter', 'demo']) {
        const list = await listImageModels(p);
        if (list.length) groups.push(`<optgroup label="${esc(P[p].short)}">${list.map(m => `<option value="${esc(p + ':' + m.id)}">${esc(m.name)}</option>`).join('')}</optgroup>`);
      }
      const locked = ['gemini', 'openai', 'openrouter'].filter(p => !Store.keys[p]);
      sel.innerHTML = groups.join('') + (locked.length ? `<optgroup label="Ajoute une clé pour débloquer">${locked.map(p => `<option disabled>${esc(P[p].short)}</option>`).join('')}</optgroup>` : '');
      const vals = [...sel.querySelectorAll('option:not([disabled])')].map(o => o.value);
      sel.value = vals.includes(s.imgModel) ? s.imgModel : (vals.find(v => !v.startsWith('demo')) || vals[0]);
    },
    async go() {
      if (this.busy) { this.busy.abort(); return; }
      const prompt = $('#i-prompt').value.trim(); const model = $('#i-model').value;
      if (!prompt) { toast('Décris d\'abord l\'image voulue'); $('#i-prompt').focus(); return; }
      const ratio = (document.querySelector('#i-ratio .on') || {}).dataset ? document.querySelector('#i-ratio .on').dataset.r : '1:1';
      const st = $('#i-status'); const btn = $('#i-go');
      this.busy = new AbortController(); btn.textContent = 'Arrêter'; btn.classList.add('ghost');
      const ph = document.createElement('div'); ph.className = 'g-it loading'; ph.style.aspectRatio = ratio.replace(':', '/'); ph.innerHTML = '<span>Création…</span>';
      $('#i-gal').prepend(ph); st.textContent = ''; const t0 = performance.now();
      try {
        const out = await generateImage({ model, prompt, ratio, refs: this.refs, signal: this.busy.signal });
        const isDemo = model.startsWith('demo'); const c = isDemo ? 0 : 0.04 * out.length;
        for (const data of out) await DB.put({ id: Store.uid(), prompt, model, ratio, data, t: Date.now() });
        Store.addUsage(model, 0, 0, c); L.updateCost();
        st.innerHTML = `<span class="ok-t">Image prête en ${((performance.now() - t0) / 1000).toFixed(1).replace('.', ',')} s</span>${isDemo ? ' · image simulée (mode démo)' : ' · coût estimé ≈ ' + c.toFixed(2).replace('.', ',') + ' $'}`;
      } catch (e) {
        const msg = /Failed to fetch|NetworkError|Load failed/i.test(e.message) ? 'Connexion impossible au fournisseur (réseau, bloqueur de pub ou clé invalide).' : e.message;
        st.innerHTML = e.name === 'AbortError' ? 'Arrêté.' : `<span class="err" style="display:block">${esc(msg)}</span>`;
      } finally {
        this.busy = null; btn.textContent = 'Générer'; btn.classList.remove('ghost'); ph.remove(); this.renderGallery();
      }
    },
    async renderGallery() {
      const g = $('#i-gal'); if (!g) return;
      let list = []; try { list = await DB.all(); } catch (e) { g.innerHTML = '<p class="hint">Galerie indisponible dans ce navigateur (navigation privée ?).</p>'; return; }
      const loading = g.querySelector('.loading');
      g.innerHTML = list.length ? list.map(i => `<button class="g-it" data-id="${i.id}" style="aspect-ratio:${i.ratio.replace(':', '/')}"><img src="${i.data}" alt="${esc(i.prompt)}" loading="lazy"><span class="g-cap">${esc(i.prompt)}</span></button>`).join('') : '<p class="hint">Tes créations apparaîtront ici. Elles restent dans ton navigateur.</p>';
      if (loading) g.prepend(loading);
    },
    async open(id) {
      const it = (await DB.all()).find(x => x.id === id); if (!it) return;
      L.modal(L.head('Image', esc(L.labelOf(it.model)) + ' · ' + new Date(it.t).toLocaleString('fr-BE')) +
        `<img src="${it.data}" alt="" style="width:100%;border-radius:12px;border:1px solid var(--line2)">
         <p style="margin:12px 0;font-size:14px">${esc(it.prompt)}</p>
         <div class="row"><button class="btn" id="g-dl">Télécharger</button><button class="btn ghost" id="g-edit">Retoucher</button><button class="btn ghost" id="g-again">Refaire une variante</button><button class="btn ghost" id="g-cp">Copier le prompt</button><button class="btn ghost" id="g-del" style="margin-left:auto">Supprimer</button></div>`, () => {
        $('#g-dl').onclick = () => { const a = document.createElement('a'); a.href = it.data; a.download = 'lilia-' + it.prompt.slice(0, 30).normalize('NFD').replace(/[^\w]+/g, '-').toLowerCase() + (it.data.startsWith('data:image/jpeg') ? '.jpg' : '.png'); a.click(); };
        $('#g-edit').onclick = () => { this.refs = [{ name: 'image.png', type: it.data.slice(5, it.data.indexOf(';')), data: it.data }]; this.drawRefs(); $('#i-prompt').value = ''; $('#i-prompt').placeholder = 'Ex. remplace le fond par une plage au coucher du soleil'; L.el.modal.close(); $('#i-prompt').focus(); };
        $('#g-again').onclick = () => { $('#i-prompt').value = it.prompt; L.el.modal.close(); this.go(); };
        $('#g-cp').onclick = () => L.copy(it.prompt);
        $('#g-del').onclick = async () => { await DB.del(id); L.el.modal.close(); this.renderGallery(); };
      });
    }
  };

  function shrink(dataUrl, max) {
    return new Promise(res => { const im = new Image(); im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)); if (k === 1) return res(dataUrl); const c = document.createElement('canvas'); c.width = im.width * k; c.height = im.height * k; c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/png')); }; im.onerror = () => res(dataUrl); im.src = dataUrl; });
  }

  /* =================== Canvas =================== */
  const CV_KEY = 'ls2.canvas';
  const cvRead = () => { try { return JSON.parse(localStorage.getItem(CV_KEY)) || []; } catch { return []; } };
  const cvWrite = l => { try { localStorage.setItem(CV_KEY, JSON.stringify(l)); } catch { toast('Stockage plein : exporte puis supprime d\'anciens textes'); } };
  const ACTIONS = [
    ['Améliorer', 'Améliore le style : plus clair, plus fluide, plus vivant. Garde le sens et le ton.'],
    ['Corriger', "Corrige uniquement l'orthographe, la grammaire et la ponctuation. Ne change rien d'autre."],
    ['Raccourcir', 'Raccourcis d\'environ 40 % en gardant l\'essentiel.'],
    ['Allonger', 'Développe avec plus de détails, d\'exemples et de nuances (environ +50 %).'],
    ['Plus simple', 'Réécris pour qu\'un débutant comprenne tout, phrases courtes, sans jargon.'],
    ['Plus pro', 'Rends le ton plus professionnel et convaincant.'],
    ['Plus fun', 'Rends le ton plus chaleureux et drôle, sans smileys.'],
    ['En néerlandais', 'Traduis en néerlandais (Belgique), naturel et idiomatique.'],
    ['En anglais', 'Traduis en anglais naturel.']
  ];

  const Cv = {
    built: false, docs: [], cur: null, undo: [], redo: [], busy: null, saveT: 0,
    show() { if (!this.built) this.build(); this.load(); },
    build() {
      this.built = true;
      $('#view-canvas').innerHTML = `
        <div class="v-wrap cv">
          <div class="cv-bar">
            <select class="inp" id="c-docs" aria-label="Mes textes"></select>
            <button class="btn ghost sm" id="c-new">+ Nouveau</button>
            <span class="cv-sp"></span>
            <button class="icon-btn" id="c-undo" title="Annuler (Ctrl Z)">↶</button><button class="icon-btn" id="c-redo" title="Rétablir">↷</button>
            <div class="seg" id="c-mode"><button data-m="edit" class="on">Écrire</button><button data-m="read">Aperçu</button></div>
            <button class="btn ghost sm" id="c-copy">Copier</button><button class="btn ghost sm" id="c-exp">Exporter</button><button class="icon-btn" id="c-del" title="Supprimer ce texte">✕</button>
          </div>
          <input class="cv-title" id="c-title" placeholder="Titre de ton texte" maxlength="90">
          <div class="cv-paper"><textarea id="c-text" placeholder="Écris ici, colle un texte… ou demande un premier jet en bas (ex. « Écris un post LinkedIn pour annoncer Lilia Studio »)."></textarea><div class="md cv-read" id="c-read" hidden></div></div>
          <div class="cv-meta"><span id="c-count">0 mot</span><span id="c-scope">L'IA agira sur tout le texte · sélectionne un passage pour cibler</span></div>
          <div class="i-styles" id="c-acts">${ACTIONS.map(([n], i) => `<button class="pill" data-a="${i}">${n}</button>`).join('')}<button class="pill" data-a="review">Relire et conseiller</button></div>
          <div class="composer cv-ask"><div class="composer-row" style="margin:0"><input class="inp" id="c-ask" placeholder="Ta consigne : « ajoute une conclusion », « écris un premier jet sur… »" style="flex:1;border:0;background:none"><button class="send" id="c-go" aria-label="Appliquer">↑</button></div></div>
          <div class="cv-notes" id="c-notes" hidden></div>
        </div>`;
      const ta = $('#c-text');
      ta.addEventListener('input', () => { this.cur.text = ta.value; this.pushUndoSoon(); this.save(); this.meta(); });
      ['select', 'keyup', 'mouseup'].forEach(ev => ta.addEventListener(ev, () => this.meta()));
      $('#c-title').addEventListener('input', e => { this.cur.title = e.target.value; this.save(); this.fillDocs(); });
      $('#c-docs').onchange = e => { this.cur = this.docs.find(d => d.id === e.target.value); this.undo = []; this.redo = []; this.paint(); };
      $('#c-new').onclick = () => this.create();
      $('#c-del').onclick = () => { if (!confirm(`Supprimer « ${this.cur.title || 'Sans titre'} » ?`)) return; this.docs = this.docs.filter(d => d !== this.cur); if (!this.docs.length) this.docs.push(this.blank()); this.cur = this.docs[0]; cvWrite(this.docs); this.paint(); };
      $('#c-undo').onclick = () => this.doUndo(); $('#c-redo').onclick = () => this.doRedo();
      ta.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !e.shiftKey && this.undo.length) { e.preventDefault(); this.doUndo(); } });
      $('#c-mode').onclick = e => { const b = e.target.closest('[data-m]'); if (!b) return; document.querySelectorAll('#c-mode button').forEach(x => x.classList.toggle('on', x === b)); const r = b.dataset.m === 'read'; ta.hidden = r; $('#c-read').hidden = !r; if (r) { $('#c-read').innerHTML = L.md(ta.value || '*Rien à afficher pour l\'instant.*'); L.decorate($('#c-read')); } };
      $('#c-copy').onclick = () => L.copy(ta.value);
      $('#c-exp').onclick = () => L.modal(L.head('Exporter') + `<div class="row"><button class="btn" data-f="md">Markdown (.md)</button><button class="btn ghost" data-f="txt">Texte (.txt)</button><button class="btn ghost" data-f="html">Page web (.html)</button></div>`, m => {
        m.querySelectorAll('[data-f]').forEach(b => b.onclick = () => {
          const name = (this.cur.title || 'texte').normalize('NFD').replace(/[^\w]+/g, '-').toLowerCase().replace(/^-|-$/g, '') || 'texte';
          const f = b.dataset.f;
          if (f === 'html') L.download(name + '.html', `<!doctype html><html lang="fr"><meta charset="utf-8"><title>${esc(this.cur.title)}</title><style>body{font:18px/1.7 Georgia,serif;max-width:720px;margin:60px auto;padding:0 20px;color:#222}</style><body>${L.md(ta.value)}</body></html>`, 'text/html');
          else L.download(name + '.' + f, ta.value, 'text/plain');
          L.el.modal.close();
        });
      });
      $('#c-acts').onclick = e => { const b = e.target.closest('[data-a]'); if (!b) return; if (b.dataset.a === 'review') this.review(); else this.apply(ACTIONS[+b.dataset.a][1]); };
      $('#c-go').onclick = () => { const v = $('#c-ask').value.trim(); if (!v) return $('#c-ask').focus(); this.apply(v); };
      $('#c-ask').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#c-go').click(); } });
    },
    blank() { return { id: Store.uid(), title: '', text: '', updated: Date.now() }; },
    load() { this.docs = cvRead(); if (!this.docs.length) this.docs.push(this.blank()); this.cur = this.cur && this.docs.find(d => d.id === this.cur.id) || this.docs[0]; this.paint(); },
    create() { const d = this.blank(); this.docs.unshift(d); this.cur = d; this.undo = []; this.redo = []; cvWrite(this.docs); this.paint(); $('#c-title').focus(); },
    paint() { $('#c-text').value = this.cur.text; $('#c-title').value = this.cur.title; this.fillDocs(); this.meta(); $('#c-notes').hidden = true; },
    fillDocs() { $('#c-docs').innerHTML = this.docs.map(d => `<option value="${d.id}" ${d === this.cur ? 'selected' : ''}>${esc(d.title || 'Sans titre')}</option>`).join(''); },
    save() { this.cur.updated = Date.now(); clearTimeout(this.saveT); this.saveT = setTimeout(() => cvWrite(this.docs), 300); },
    sel() { const ta = $('#c-text'); return ta.selectionEnd > ta.selectionStart ? [ta.selectionStart, ta.selectionEnd] : null; },
    meta() {
      const v = $('#c-text').value; const w = (v.match(/\S+/g) || []).length; $('#c-count').textContent = w + (w > 1 ? ' mots' : ' mot');
      const s = this.sel(); $('#c-scope').textContent = s ? `L'IA agira sur la sélection (${(v.slice(s[0], s[1]).match(/\S+/g) || []).length} mots)` : (v.trim() ? "L'IA agira sur tout le texte · sélectionne un passage pour cibler" : 'Texte vide : donne une consigne pour un premier jet');
    },
    pushUndoSoon() { if (!this._pending) { this.undo.push(this._last != null ? this._last : ''); this.redo = []; this._pending = setTimeout(() => { this._pending = 0; }, 1200); } this._last = $('#c-text').value; },
    snapshot() { this.undo.push($('#c-text').value); this.redo = []; if (this.undo.length > 80) this.undo.shift(); },
    setText(t) { $('#c-text').value = t; this.cur.text = t; this._last = t; this.save(); this.meta(); },
    doUndo() { if (!this.undo.length) return; this.redo.push($('#c-text').value); this.setText(this.undo.pop()); },
    doRedo() { if (!this.redo.length) return; this.undo.push($('#c-text').value); this.setText(this.redo.pop()); },
    model() { const s = Store.settings; return s.model; },
    async apply(instruction) {
      if (this.busy) { this.busy.abort(); return; }
      const ta = $('#c-text'); const full = ta.value; const s = this.sel();
      const [a, b] = s || [0, full.length]; const part = full.slice(a, b);
      const draft = !full.trim();
      const model = this.model(); const [p] = AI.split(model);
      this.snapshot(); $('#c-mode [data-m="edit"]').click();
      const sys = "Tu es l'éditeur de Lilia Studio (mode CANVAS). Tu renvoies UNIQUEMENT le texte final demandé, en Markdown si utile, sans introduction, sans commentaire, sans guillemets autour. Conserve la langue du texte sauf si on te demande une traduction.";
      const user = draft ? `Consigne : ${instruction}\n\nÉcris le texte complet.`
        : `Texte complet (pour le contexte) :\n<<<\n${full}\n>>>\n\n${s ? 'Passage à réécrire :\n<<<\n' + part + '\n>>>\n\n' : ''}Consigne : ${instruction}\n\nRenvoie uniquement ${s ? 'le passage réécrit' : 'le texte complet réécrit'}.`;
      const before = full.slice(0, a), after = full.slice(b);
      this.busy = new AbortController(); this.lock(true);
      try {
        if (p === 'demo') { await this.demo(instruction, part, draft, before, after); return; }
        let raf = 0;
        const r = await AI.chat({ model, messages: [{ role: 'user', content: user }], system: sys, temperature: Store.settings.temperature, maxTokens: Math.max(Store.settings.maxTokens, 4096), signal: this.busy.signal,
          onDelta: (_, all) => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; ta.value = before + all + after; }); } });
        if (raf) cancelAnimationFrame(raf);
        const out = r.text.replace(/^<<<\n?|\n?>>>$/g, '');
        this.setText(before + out + after);
        ta.setSelectionRange(a, a + out.length); ta.focus();
        Store.addUsage(model, r.inTok, r.outTok, r.cost); L.updateCost();
        if (!this.cur.title && draft) { this.cur.title = (out.match(/^#+\s*(.+)$/m) || [])[1] || instruction.slice(0, 50); $('#c-title').value = this.cur.title; this.fillDocs(); }
        $('#c-ask').value = ''; toast('Fait. Ctrl Z ou ↶ pour annuler.');
      } catch (e) {
        if (e.name !== 'AbortError') { this.setText(full); this.undo.pop(); toast(e.message, 6000); if (e.needKey) L.openSettings('keys'); }
        else toast('Arrêté');
      } finally { this.busy = null; this.lock(false); }
    },
    async demo(instruction, part, draft, before, after) {
      const sample = draft ? `# ${instruction.replace(/^(écris|ecris|rédige|fais)\s+(moi\s+)?/i, '').slice(0, 60)}\n\nCeci est un **premier jet simulé** par le mode démo de Lilia Studio. Avec une vraie clé (Gemini gratuite, ou Claude), l'IA écrira ici un texte complet selon ta consigne.\n\nTu pourras ensuite le sélectionner et cliquer sur *Améliorer*, *Raccourcir* ou *En néerlandais*.`
        : part + '\n\n> *Mode démo : texte inchangé. Ajoute une clé pour que l\'IA applique « ' + instruction.slice(0, 60) + ' ».*';
      const ta = $('#c-text'); let acc = '';
      for (const ch of sample.match(/[\s\S]{1,5}/g)) { if (this.busy.signal.aborted) break; acc += ch; ta.value = before + acc + after; await new Promise(r => setTimeout(r, 12)); }
      this.setText(before + acc + after); toast('Mode démo : ajoute une clé pour une vraie réécriture', 4000);
    },
    async review() {
      const t = $('#c-text').value.trim(); if (!t) return toast('Écris ou génère d\'abord un texte');
      if (this.busy) return;
      const model = this.model(); const n = $('#c-notes'); n.hidden = false; n.innerHTML = '<span class="k">RELECTURE</span><div class="md cursor"></div>';
      const box = n.querySelector('.md');
      if (AI.split(model)[0] === 'demo') { box.classList.remove('cursor'); box.innerHTML = L.md('- *Mode démo* : ajoute une clé pour une vraie relecture.\n- Astuce : une phrase = une idée.\n- Termine par un appel à l\'action clair.'); return; }
      this.busy = new AbortController(); this.lock(true);
      try {
        const r = await AI.chat({ model, messages: [{ role: 'user', content: `Relis ce texte et donne 3 à 6 conseils concrets, du plus important au moins important (liste à puces, une ligne chacun, cite le passage concerné). Puis une note sur 10.\n\n${t}` }], system: 'Tu es un relecteur exigeant et bienveillant. Réponds en français.', maxTokens: 1500, temperature: 0.4, signal: this.busy.signal,
          onDelta: (_, all) => { box.innerHTML = L.md(all); } });
        box.classList.remove('cursor'); box.innerHTML = L.md(r.text); Store.addUsage(model, r.inTok, r.outTok, r.cost); L.updateCost();
      } catch (e) { box.classList.remove('cursor'); box.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
      finally { this.busy = null; this.lock(false); }
    },
    lock(on) { $('#c-text').readOnly = on; $('#c-go').textContent = on ? '■' : '↑'; $('#c-go').classList.toggle('stop', on); document.querySelectorAll('#c-acts button').forEach(b => b.disabled = on); $('#view-canvas .cv-paper').classList.toggle('working', on); }
  };

  // Palette Ctrl K : ajoute les espaces (la palette lit commands() à chaque ouverture via ce hook)
  window.LSviews = { setView };
})();
