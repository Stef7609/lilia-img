/* Lilia Studio 2 — stockage local (tout reste dans le navigateur) */
(function () {
  'use strict';
  const NS = 'ls2.';
  const read = (k, d) => { try { const v = localStorage.getItem(NS + k); return v == null ? d : JSON.parse(v); } catch { return d; } };
  const write = (k, v) => { try { localStorage.setItem(NS + k, JSON.stringify(v)); return true; } catch (e) { console.warn('stockage plein ?', e); return false; } };
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  const DEFAULT_ROLES = [
    { id: 'r-dev', name: 'Développeur senior', short: 'Dev', prompt: "Tu es un développeur senior pragmatique. Tu écris du code propre, commenté en français quand c'est utile, et tu expliques brièvement tes choix. Quand on te demande une page, un jeu ou une mini-appli, livre un seul fichier HTML complet et autonome dans un bloc ```html." },
    { id: 'r-mkt', name: 'Expert marketing', short: 'Marketing', prompt: "Tu es un expert marketing digital francophone. Tu proposes des accroches percutantes, des plans de contenu concrets pour Facebook, Instagram, TikTok et LinkedIn, avec hashtags pertinents. Ton direct, sans jargon inutile." },
    { id: 'r-cons', name: 'Consultant business', short: 'Consultant', prompt: "Tu es un consultant business qui va droit au but : diagnostic, 3 options chiffrées quand c'est possible, recommandation claire, prochaines étapes." },
    { id: 'r-prof', name: 'Prof patient', short: 'Prof', prompt: "Tu expliques simplement, étape par étape, avec des exemples du quotidien. Tu vérifies la compréhension avec une petite question à la fin." },
    { id: 'r-write', name: 'Plume créative', short: 'Plume', prompt: "Tu es un écrivain talentueux. Style vivant, images fortes, rythme soigné. Tu respectes le ton demandé (drôle, sombre, poétique…)." },
    { id: 'r-crit', name: 'Critique honnête', short: 'Critique', prompt: "Tu relis avec franchise. Points forts, points faibles, corrections concrètes, par ordre d'importance. Pas de flatterie." }
  ];

  const DEFAULT_PROMPTS = [
    { id: 'p-landing', cmd: 'landing', title: 'Page de vente', text: "Crée une landing page moderne, sombre et élégante pour : {{sujet}}. Hero accrocheur, 3 avantages, témoignage, appel à l'action. Un seul fichier HTML responsive." },
    { id: 'p-jeu', cmd: 'jeu', title: 'Mini-jeu', text: "Crée un mini-jeu jouable dans le navigateur sur le thème : {{thème}}. Commandes clavier et tactile, score, écran de fin. Un seul fichier HTML." },
    { id: 'p-post', cmd: 'post', title: 'Post réseaux sociaux', text: "Écris 3 versions d'un post pour Facebook, Instagram et TikTok sur : {{sujet}}. Accroche forte en première ligne, appel à l'action, hashtags." },
    { id: 'p-resume', cmd: 'resume', title: 'Résumé express', text: "Résume ce texte en 5 points clés puis donne une phrase de conclusion :\n\n{{texte}}" },
    { id: 'p-mail', cmd: 'mail', title: 'E-mail pro', text: "Rédige un e-mail professionnel et cordial pour : {{objectif}}. Objet + corps, court et clair." },
    { id: 'p-explique', cmd: 'explique', title: 'Explique-moi', text: "Explique-moi {{sujet}} comme si j'avais 12 ans, puis donne la version expert en 3 lignes." },
    { id: 'p-code', cmd: 'debug', title: 'Débogue mon code', text: "Trouve et corrige les bugs de ce code. Explique chaque correction en une ligne :\n\n{{code}}" }
  ];

  const DEFAULT_SETTINGS = {
    model: 'demo:lilia-demo',
    roleId: null,
    arenaModels: ['demo:lilia-demo', 'demo:lilia-demo-vif', 'demo:lilia-demo-poete'],
    temperature: 0.7,
    maxTokens: 4096,
    budget: 5,
    autoArtifact: true,
    lang: 'fr',
    system: ''
  };

  const Store = {
    uid,
    get settings() { return Object.assign({}, DEFAULT_SETTINGS, read('settings', {})); },
    saveSettings(patch) { const s = Object.assign(this.settings, patch); write('settings', s); return s; },

    get keys() { return read('keys', {}); },
    setKey(p, v) { const k = this.keys; if (v) k[p] = v.trim(); else delete k[p]; write('keys', k); },

    get roles() { return read('roles', null) || DEFAULT_ROLES.slice(); },
    saveRoles(r) { write('roles', r); },
    get prompts() { return read('prompts', null) || DEFAULT_PROMPTS.slice(); },
    savePrompts(p) { write('prompts', p); },

    sessions() { return read('sessions', []); },
    saveSessions(list) {
      if (!write('sessions', list)) {
        // trop gros : on enlève les images jointes des anciennes sessions
        list.slice(10).forEach(s => s.messages.forEach(m => { if (m.files) m.files = m.files.map(f => ({ name: f.name, type: f.type })); }));
        write('sessions', list);
      }
    },
    newSession(title) { return { id: uid(), title: title || 'Nouvelle session', created: Date.now(), updated: Date.now(), messages: [], pinned: false }; },

    get usage() { return read('usage', {}); },
    addUsage(model, inTok, outTok, cost) {
      const u = this.usage; const day = new Date().toISOString().slice(0, 10);
      const d = u[day] || (u[day] = { msgs: 0, in: 0, out: 0, cost: 0, models: {} });
      d.msgs++; d.in += inTok; d.out += outTok; d.cost += cost;
      d.models[model] = (d.models[model] || 0) + 1;
      write('usage', u);
    },
    monthCost() {
      const m = new Date().toISOString().slice(0, 7); let c = 0;
      for (const [d, v] of Object.entries(this.usage)) if (d.startsWith(m)) c += v.cost;
      return c;
    },
    modelCache(p, list) { const c = read('models', {}); if (list) { c[p] = { t: Date.now(), list }; write('models', c); } return c[p]; },

    exportAll() {
      const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith(NS) && k !== NS + 'keys') o[k] = localStorage.getItem(k); }
      return JSON.stringify({ app: 'lilia-studio-2', v: 1, date: new Date().toISOString(), data: o }, null, 1);
    },
    importAll(json) {
      const o = JSON.parse(json); if (o.app !== 'lilia-studio-2') throw new Error('Fichier non reconnu');
      for (const [k, v] of Object.entries(o.data)) if (k.startsWith(NS) && k !== NS + 'keys') localStorage.setItem(k, v);
    },
    wipe() { Object.keys(localStorage).filter(k => k.startsWith(NS)).forEach(k => localStorage.removeItem(k)); }
  };

  window.Store = Store;
})();
