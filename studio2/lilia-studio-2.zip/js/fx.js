/* Lilia Studio 2 — effets de l'accueil : l'œil suit le curseur, cligne, constellation vivante */
(function () {
  'use strict';
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const home = document.getElementById('home'), eye = home && home.querySelector('.home-eye');
  if (!eye) return;
  // constellation
  const cv = document.createElement('canvas'); cv.className = 'fx-sky'; home.prepend(cv);
  const ctx = cv.getContext('2d'); let W = 0, H = 0, dpr = Math.min(2, devicePixelRatio || 1);
  const pts = []; const N = innerWidth < 700 ? 38 : 70;
  const mouse = { x: -1e4, y: -1e4, tx: 0, ty: 0 };
  function size() { const r = home.getBoundingClientRect(); W = r.width; H = Math.max(r.height, 420); cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px'; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
  for (let i = 0; i < N; i++) pts.push({ x: Math.random(), y: Math.random(), vx: (Math.random() - .5) * .0004, vy: (Math.random() - .5) * .0004, r: Math.random() * 1.6 + .4 });
  addEventListener('resize', size); size();
  addEventListener('pointermove', e => { const r = home.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; mouse.tx = (e.clientX / innerWidth - .5) * 2; mouse.ty = (e.clientY / innerHeight - .5) * 2; });
  // clic sur l'œil : onde rubis
  const waves = [];
  eye.style.cursor = 'pointer';
  eye.addEventListener('click', () => { const r = eye.getBoundingClientRect(), h = home.getBoundingClientRect(); waves.push({ x: r.left + r.width / 2 - h.left, y: r.top + r.height / 2 - h.top, t: 0 }); blink(); });
  let rx = 0, ry = 0, blinkT = -1, next = performance.now() + 2500;
  function blink() { blinkT = performance.now(); }
  function frame(now) {
    if (!home.offsetParent) { requestAnimationFrame(frame); return; }
    // œil : suit le curseur
    rx += (mouse.ty * -14 - rx) * .08; ry += (mouse.tx * 18 - ry) * .08;
    if (now > next) { blink(); next = now + 4000 + Math.random() * 4000; }
    let sy = 1; if (blinkT > 0) { const k = (now - blinkT) / 220; if (k < 1) sy = 1 - Math.sin(k * Math.PI) * .9; else blinkT = -1; }
    eye.style.transform = `perspective(700px) rotateX(${rx}deg) rotateY(${ry}deg) scaleY(${sy}) translateY(${Math.sin(now / 1000) * -5}px)`;
    eye.style.filter = `drop-shadow(${-ry * .8}px ${10 + rx * .6}px 40px #FF2E5077)`;
    // ciel
    ctx.clearRect(0, 0, W, H);
    for (const p of pts) { p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > 1) p.vx *= -1; if (p.y < 0 || p.y > 1) p.vy *= -1; }
    for (let i = 0; i < pts.length; i++) {
      const a = pts[i], ax = a.x * W, ay = a.y * H;
      const dm = Math.hypot(ax - mouse.x, ay - mouse.y), near = Math.max(0, 1 - dm / 180);
      ctx.fillStyle = `rgba(255,${90 + near * 120},${110 + near * 100},${.35 + near * .6})`; ctx.beginPath(); ctx.arc(ax, ay, a.r + near * 1.6, 0, 7); ctx.fill();
      for (let j = i + 1; j < pts.length; j++) { const b = pts[j], d = Math.hypot(ax - b.x * W, ay - b.y * H); if (d < 120) { ctx.strokeStyle = `rgba(255,46,80,${(1 - d / 120) * (.12 + near * .5)})`; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(b.x * W, b.y * H); ctx.stroke(); } }
      if (near > 0) { ctx.strokeStyle = `rgba(255,46,80,${near * .5})`; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(mouse.x, mouse.y); ctx.stroke(); }
    }
    for (let k = waves.length - 1; k >= 0; k--) { const w = waves[k]; w.t += 1 / 60; const r = w.t * 520; ctx.strokeStyle = `rgba(255,46,80,${Math.max(0, 1 - w.t * 1.4)})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(w.x, w.y, r, 0, 7); ctx.stroke(); if (w.t > .8) waves.splice(k, 1); }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
