/* Lilia Studio 2 — interface */
(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = n => (n < 0.01 && n > 0 ? n.toFixed(4) : n.toFixed(2)).replace('.', ',') + ' $';
  const P = AI.PROVIDERS;

  marked.setOptions({ gfm: true, breaks: true });
  const md = t => DOMPurify.sanitize(marked.parse(t || ''), { ADD_ATTR: ['target'] });

  /* ---------- État ---------- */
  let sessions = Store.sessions();
  let cur = null;               // session ouverte
  let files = [];               // pièces jointes en attente
  let busy = null;              // AbortController en cours
  let arenaOn = false;
  let artifact = { html: '', name: 'artefact.html' };

  const el = {
    main: $('#main'), thread: $('#thread'), input: $('#input'), send: $('#send'), sessions: $('#sessions'),
    side: $('#side'), scrim: $('#scrim'), modal: $('#modal'), mi: $('#modal-inner'), toast: $('#toast'),
    att: $('#attachments'), slash: $('#slash'), art: $('#artifact'), frame: $('#art-frame'), code: $('#art-code')
  };

  function toast(msg, ms) {
    el.toast.textContent = msg; el.toast.classList.add('show');
    clearTimeout(toast.t); toast.t = setTimeout(() => el.toast.classList.remove('show'), ms || 2600);
  }

  /* ---------- Sessions ---------- */
  function save() { if (cur) { cur.updated = Date.now(); } sessions.sort((a, b) => (b.pinned - a.pinned) || (b.updated - a.updated)); Store.saveSessions(sessions); renderSessions(); }

  function renderSessions() {
    const q = $('#search').value.trim().toLowerCase();
    const list = sessions.filter(s => !q || s.title.toLowerCase().includes(q) || s.messages.some(m => (m.content || '').toLowerCase().includes(q)));
    if (!list.length) { el.sessions.innerHTML = `<div class="empty-side">${q ? 'Aucun résultat.' : 'Tes sessions apparaîtront ici.'}</div>`; return; }
    const now = new Date(); const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const groups = [['Épinglées', s => s.pinned], ["Aujourd'hui", s => s.updated >= today], ['7 derniers jours', s => s.updated >= today - 6 * 864e5], ['Plus ancien', () => true]];
    const used = new Set(); let html = '';
    for (const [name, fn] of groups) {
      const g = list.filter(s => !used.has(s.id) && fn(s)); if (!g.length) continue;
      g.forEach(s => used.add(s.id));
      html += `<div class="lab">${name}</div>` + g.map(s => `<div class="it${cur && cur.id === s.id ? ' on' : ''}" role="button" tabindex="0" data-id="${s.id}" title="Double-clic pour renommer"><i class="dot"></i><span class="t">${esc(s.title)}</span>${s.pinned ? '<span class="pin">●</span>' : ''}<button class="del" data-pin="${s.id}" title="${s.pinned ? 'Désépingler' : 'Épingler'}">${s.pinned ? '◆' : '◇'}</button><button class="del" data-del="${s.id}" title="Supprimer">✕</button></div>`).join('');
    }
    el.sessions.innerHTML = html;
  }

  el.sessions.addEventListener('click', e => {
    const del = e.target.closest('[data-del]'), pin = e.target.closest('[data-pin]');
    if (del) {
      e.stopPropagation();
      const s = sessions.find(x => x.id === del.dataset.del);
      if (!confirm(`Supprimer « ${s.title} » ? C'est définitif.`)) return;
      sessions = sessions.filter(x => x.id !== s.id);
      if (cur && cur.id === s.id) newSession(); else save();
      return;
    }
    if (pin) { e.stopPropagation(); const s = sessions.find(x => x.id === pin.dataset.pin); s.pinned = !s.pinned; save(); return; }
    const it = e.target.closest('.it'); if (it) { openSession(it.dataset.id); closeSide(); }
  });
  el.sessions.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.classList.contains('it')) openSession(e.target.dataset.id); });
  el.sessions.addEventListener('dblclick', e => {
    const it = e.target.closest('.it'); if (!it) return;
    const s = sessions.find(x => x.id === it.dataset.id);
    const t = prompt('Nouveau nom de la session :', s.title);
    if (t && t.trim()) { s.title = t.trim().slice(0, 80); save(); if (cur === s) $('#top-title').textContent = s.title; }
  });
  $('#search').addEventListener('input', renderSessions);

  function newSession() {
    if (busy) busy.abort();
    cur = null; files = []; renderAtt();
    el.thread.innerHTML = ''; el.main.classList.remove('chatting');
    $('#top-title').textContent = '';
    renderSessions(); el.input.value = ''; autosize(); el.input.focus();
  }
  function openSession(id) {
    if (busy) busy.abort();
    cur = sessions.find(s => s.id === id); if (!cur) return;
    $('#top-title').textContent = cur.title;
    el.main.classList.toggle('chatting', cur.messages.length > 0);
    renderThread(); renderSessions();
  }
  function ensureSession(firstText) {
    if (cur) return cur;
    cur = Store.newSession((firstText || 'Nouvelle session').replace(/\s+/g, ' ').slice(0, 48));
    sessions.unshift(cur); $('#top-title').textContent = cur.title;
    return cur;
  }

  /* ---------- Rendu des messages ---------- */
  const eyeImg = '<img src="img/eye.png" alt="">';
  function labelOf(full) {
    const [p, id] = AI.split(full || '');
    const list = (AI.listModels.cache && AI.listModels.cache[p]) || P[p] && P[p].defaults || [];
    const f = list.find(m => m.id === id);
    return f ? f.name : id || '?';
  }

  function decorate(container) {
    container.querySelectorAll('pre').forEach(pre => {
      if (pre.querySelector('.pre-bar')) return;
      const code = pre.querySelector('code'); if (!code) return;
      const lang = ((code.className.match(/language-(\w+)/) || [])[1] || 'code').toLowerCase();
      const bar = document.createElement('div'); bar.className = 'pre-bar';
      bar.innerHTML = `<span>${esc(lang)}</span>${/^(html|svg|xml)$/.test(lang) ? '<button data-act="art">Ouvrir l\'aperçu</button>' : ''}<button data-act="copy">Copier</button>`;
      pre.prepend(bar);
    });
    container.querySelectorAll('a[href^="http"]').forEach(a => { a.target = '_blank'; a.rel = 'noopener'; });
  }

  function msgNode(m, idx) {
    const d = document.createElement('div');
    if (m.role === 'user') {
      d.className = 'msg user';
      const att = (m.files || []).length ? `<div class="att">${m.files.map(f => attChip(f)).join('')}</div>` : '';
      d.innerHTML = `<div><div class="bubble">${att}${esc(m.content)}</div><div class="acts" style="justify-content:flex-end"><button data-act="edit" data-i="${idx}">Modifier</button><button data-act="copy-msg" data-i="${idx}">Copier</button></div></div>`;
      return d;
    }
    if (m.arena) return arenaNode(m, idx);
    d.className = 'msg ai';
    d.innerHTML = `<div class="av">${eyeImg}</div><div class="body"><div class="meta"><b>${esc(labelOf(m.model))}</b>${m.ms ? `<span>${(m.ms / 1000).toFixed(1).replace('.', ',')} s</span>` : ''}${m.cost != null ? `<span>${money(m.cost)}</span>` : ''}${m.role_name ? `<span>${esc(m.role_name)}</span>` : ''}</div><div class="md"></div>${m.error ? `<div class="err">${esc(m.error)} <button data-act="retry" data-i="${idx}">Réessayer</button>${m.needKey ? ` <button data-open="settings">Ouvrir les réglages</button> <button data-open="guide">C'est quoi une clé ?</button>` : ''}</div>` : ''}<div class="acts"><button data-act="copy-msg" data-i="${idx}">Copier</button><button data-act="retry" data-i="${idx}">Régénérer</button><button data-act="speak" data-i="${idx}">Écouter</button></div></div>`;
    const box = d.querySelector('.md'); box.innerHTML = md(m.content); decorate(box);
    const h = extractHtml(m.content);
    if (h) box.insertAdjacentHTML('afterend', `<button class="art-card" data-act="art-open" data-i="${idx}"><span class="ic">&lt;/&gt;</span><span><b>${esc(titleOfHtml(h))}</b><span>Artefact HTML · clique pour l'aperçu</span></span></button>`);
    return d;
  }

  function arenaNode(m, idx) {
    const d = document.createElement('div'); d.className = 'arena';
    d.innerHTML = `<div class="meta" style="max-width:1180px"><span class="k">ARÈNE · ${m.arena.length} IA</span>${m.win == null ? '<span>Choisis la meilleure réponse pour continuer avec elle.</span>' : ''}</div><div class="arena-cols" style="--n:${m.arena.length}">${m.arena.map((a, j) => `
      <div class="arena-col${m.win === j ? ' win' : ''}" data-j="${j}"><div class="h"><span class="dot-live${a.model.startsWith('demo') ? ' demo' : ''}"></span><b>${esc(labelOf(a.model))}${m.win === j ? ' ★' : ''}</b></div>
      <div class="md">${a.error ? `<div class="err">${esc(a.error)}</div>` : md(a.text)}</div>
      <div class="f">${a.ms ? `<span>${(a.ms / 1000).toFixed(1).replace('.', ',')} s</span>` : '<span>…</span>'}${a.cost != null ? `<span>${money(a.cost)}</span>` : ''}<button data-act="win" data-i="${idx}" data-j="${j}">${m.win === j ? 'Gagnante' : 'Choisir'}</button></div></div>`).join('')}</div>`;
    d.querySelectorAll('.md').forEach(decorate);
    return d;
  }

  function renderThread() {
    el.thread.innerHTML = '';
    if (!cur) return;
    cur.messages.forEach((m, i) => el.thread.appendChild(msgNode(m, i)));
    el.thread.scrollTop = el.thread.scrollHeight;
  }

  /* ---------- Artefacts ---------- */
  function extractHtml(t) {
    if (!t) return '';
    const m = t.match(/```(?:html|HTML)\s*\n([\s\S]*?)```/) || t.match(/```(?:svg)\s*\n([\s\S]*?)```/);
    if (m && /<(html|body|div|svg|canvas|section|main|!doctype)/i.test(m[1])) return m[1].trim();
    return '';
  }
  const titleOfHtml = h => ((h.match(/<title>([^<]*)<\/title>/i) || [])[1] || 'Page HTML').trim().slice(0, 60);

  function openArtifact(html) {
    artifact.html = html; artifact.name = (titleOfHtml(html).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'artefact') + '.html';
    el.art.hidden = false;
    el.frame.srcdoc = html;
    el.code.textContent = html;
    setArtView('preview');
  }
  function setArtView(v) {
    $$('#art-seg button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
    el.frame.hidden = v !== 'preview'; el.code.hidden = v !== 'code';
  }
  $('#art-seg').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setArtView(b.dataset.v); });
  $('#art-size').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    $$('#art-size button').forEach(x => x.classList.toggle('on', x === b));
    el.frame.style.width = b.dataset.w; setArtView('preview');
  });
  $('#art-close').onclick = () => { el.art.hidden = true; el.frame.srcdoc = ''; };
  $('#art-dl').onclick = () => download(artifact.name, artifact.html, 'text/html');

  function download(name, content, type) {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([content], { type })); a.download = name;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  /* ---------- Actions dans le fil ---------- */
  el.thread.addEventListener('click', async e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    const act = b.dataset.act, i = +b.dataset.i, m = cur && cur.messages[i];
    if (act === 'copy') { const code = b.closest('pre').querySelector('code').textContent; copy(code); }
    else if (act === 'art') openArtifact(b.closest('pre').querySelector('code').textContent);
    else if (act === 'art-open') openArtifact(extractHtml(m.content));
    else if (act === 'copy-msg') copy(m.content);
    else if (act === 'speak') speak(m.content, b);
    else if (act === 'edit') {
      if (busy) return;
      el.input.value = m.content; files = (m.files || []).slice(); renderAtt(); autosize();
      cur.messages.splice(i); save(); renderThread(); el.main.classList.toggle('chatting', cur.messages.length > 0); el.input.focus();
    } else if (act === 'retry') {
      if (busy) return;
      cur.messages.splice(m.role === 'assistant' ? i : i + 1); save(); renderThread(); run();
    } else if (act === 'win') {
      const j = +b.dataset.j; if (m.arena[j].error) return;
      m.win = j; m.content = m.arena[j].text; m.model = m.arena[j].model; save(); renderThread();
      toast('Réponse choisie : la conversation continue avec ' + labelOf(m.model));
    }
  });

  function copy(t) { navigator.clipboard.writeText(t).then(() => toast('Copié'), () => toast('Copie impossible')); }

  /* ---------- Envoi ---------- */
  function systemPrompt() {
    const st = Store.settings; const role = Store.roles.find(r => r.id === st.roleId);
    const base = "Tu es Lilia, l'assistante de Lilia Studio. Réponds en français par défaut (ou dans la langue de l'utilisateur), de façon claire et structurée en Markdown. Quand on te demande une page web, un jeu, une animation ou une mini-appli, fournis un seul fichier HTML complet et autonome (CSS et JS inclus) dans un bloc ```html : il s'affichera en direct dans le panneau Artefact.";
    return [base, role ? role.prompt : '', st.system].filter(Boolean).join('\n\n');
  }
  const history = () => cur.messages.filter(m => !m.error && (m.role === 'user' || (m.content && m.content !== '*(arrêté)*'))).map(m => ({ role: m.role, content: m.content, files: m.files }));

  async function sendMessage() {
    if (busy) { busy.abort(); return; }
    const text = el.input.value.trim();
    if (!text && !files.length) { el.input.focus(); return; }
    if (/\{\{[^}]+\}\}/.test(text)) { toast('Remplace d\'abord les {{champs}} de ton prompt'); selectVar(); return; }
    const st = Store.settings;
    if (st.budget > 0 && Store.monthCost() >= st.budget && !confirm(`Budget du mois atteint (${money(Store.monthCost())} / ${money(st.budget)}). Continuer quand même ?`)) return;
    ensureSession(text || files[0].name);
    cur.messages.push({ role: 'user', content: text, files: files.slice(), t: Date.now() });
    el.input.value = ''; files = []; renderAtt(); autosize(); hideSlash();
    el.main.classList.add('chatting');
    save(); renderThread();
    await run();
  }

  async function run() {
    const st = Store.settings;
    if (arenaOn) return runArena();
    const role = Store.roles.find(r => r.id === st.roleId);
    const m = { role: 'assistant', content: '', model: st.model, t: Date.now(), role_name: role ? role.short : '' };
    cur.messages.push(m);
    const idx = cur.messages.length - 1;
    const node = msgNode(m, idx); el.thread.appendChild(node);
    const box = node.querySelector('.md'); box.classList.add('cursor');
    setBusy(true);
    let raf = 0;
    const paint = () => { raf = 0; box.innerHTML = md(m.content); box.classList.add('cursor'); stick(); };
    try {
      const r = await AI.chat({
        model: st.model, messages: history(), system: systemPrompt(), temperature: st.temperature, maxTokens: st.maxTokens, signal: busy.signal,
        onDelta: (_, all) => { m.content = all; if (!raf) raf = requestAnimationFrame(paint); }
      });
      Object.assign(m, { content: r.text, ms: r.ms, cost: r.cost });
      Store.addUsage(st.model, r.inTok, r.outTok, r.cost);
      const h = extractHtml(r.text);
      if (h && st.autoArtifact) openArtifact(h);
    } catch (e) {
      if (e.name === 'AbortError') { if (!m.content) m.content = '*(arrêté)*'; }
      else { m.error = e.message || String(e); m.needKey = !!e.needKey; if (/Failed to fetch|NetworkError|Load failed/i.test(m.error)) m.error = 'Connexion impossible au fournisseur (réseau, bloqueur de pub ou clé invalide).'; }
    } finally {
      if (raf) cancelAnimationFrame(raf);
      setBusy(false); save();
      node.replaceWith(msgNode(m, idx)); stick(true); updateCost();
    }
  }

  async function runArena() {
    const st = Store.settings;
    const models = st.arenaModels.slice(0, 3);
    const m = { role: 'assistant', content: '', arena: models.map(model => ({ model, text: '' })), win: null, t: Date.now() };
    cur.messages.push(m);
    const idx = cur.messages.length - 1;
    let node = arenaNode(m, idx); el.thread.appendChild(node);
    setBusy(true);
    const hist = history();
    const repaint = j => { const col = node.querySelectorAll('.arena-col')[j]; if (col) { const b = col.querySelector('.md'); b.innerHTML = md(m.arena[j].text); b.classList.add('cursor'); } stick(); };
    await Promise.all(m.arena.map(async (a, j) => {
      let raf = 0;
      try {
        const r = await AI.chat({ model: a.model, messages: hist, system: systemPrompt(), temperature: st.temperature, maxTokens: st.maxTokens, signal: busy.signal,
          onDelta: (_, all) => { a.text = all; if (!raf) raf = requestAnimationFrame(() => { raf = 0; repaint(j); }); } });
        Object.assign(a, { text: r.text, ms: r.ms, cost: r.cost });
        Store.addUsage(a.model, r.inTok, r.outTok, r.cost);
      } catch (e) { if (e.name !== 'AbortError') a.error = e.message; else if (!a.text) a.text = '*(arrêté)*'; }
      if (raf) cancelAnimationFrame(raf);
    }));
    const ok = m.arena.findIndex(a => !a.error);
    m.content = ok >= 0 ? m.arena[ok].text : ''; m.model = ok >= 0 ? m.arena[ok].model : models[0];
    if (ok < 0) m.error = 'Aucune IA n\'a pu répondre.';
    setBusy(false); save();
    node.replaceWith(arenaNode(m, idx)); stick(true); updateCost();
  }

  function stick(force) { const t = el.thread; if (force || t.scrollHeight - t.scrollTop - t.clientHeight < 160) t.scrollTop = t.scrollHeight; }
  function setBusy(on) {
    busy = on ? new AbortController() : null;
    el.send.classList.toggle('stop', on); el.send.textContent = on ? '■' : '↑';
    el.send.setAttribute('aria-label', on ? 'Arrêter' : 'Envoyer');
  }

  /* ---------- Composer ---------- */
  function autosize() { el.input.style.height = 'auto'; el.input.style.height = Math.min(el.input.scrollHeight, innerHeight * 0.4) + 'px'; }
  el.input.addEventListener('input', () => { autosize(); slashCheck(); });
  el.input.addEventListener('keydown', e => {
    if (!el.slash.hidden && ['ArrowDown', 'ArrowUp', 'Enter', 'Tab', 'Escape'].includes(e.key)) return slashKey(e);
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendMessage(); }
  });
  el.send.onclick = sendMessage;

  // Slash : prompts enregistrés
  let slashSel = 0, slashItems = [];
  function slashCheck() {
    const v = el.input.value; const m = v.match(/^\/(\S*)$/);
    if (!m) return hideSlash();
    const q = m[1].toLowerCase();
    slashItems = Store.prompts.filter(p => p.cmd.includes(q) || p.title.toLowerCase().includes(q)).slice(0, 8);
    if (!slashItems.length) return hideSlash();
    slashSel = 0; drawSlash(); el.slash.hidden = false;
  }
  function drawSlash() { el.slash.innerHTML = slashItems.map((p, i) => `<button class="${i === slashSel ? 'on' : ''}" data-i="${i}"><b>/${esc(p.cmd)}</b>${esc(p.title)}<span>${esc(p.text.slice(0, 70))}</span></button>`).join(''); }
  function hideSlash() { el.slash.hidden = true; }
  function slashKey(e) {
    e.preventDefault();
    if (e.key === 'ArrowDown') slashSel = (slashSel + 1) % slashItems.length;
    else if (e.key === 'ArrowUp') slashSel = (slashSel - 1 + slashItems.length) % slashItems.length;
    else if (e.key === 'Escape') return hideSlash();
    else return usePrompt(slashItems[slashSel]);
    drawSlash();
  }
  el.slash.addEventListener('mousedown', e => { const b = e.target.closest('button'); if (b) { e.preventDefault(); usePrompt(slashItems[+b.dataset.i]); } });
  function usePrompt(p) { hideSlash(); el.input.value = p.text; autosize(); el.input.focus(); selectVar(); }
  function selectVar() {
    const m = /\{\{[^}]+\}\}/.exec(el.input.value);
    if (m) { el.input.focus(); el.input.setSelectionRange(m.index, m.index + m[0].length); }
  }

  // Fichiers
  function attChip(f, i) {
    const img = f.type && f.type.startsWith('image/') && f.data;
    return `<span class="att-chip">${img ? `<img src="${f.data}" alt="">` : `<span class="fi">${esc((f.name.split('.').pop() || 'TXT').slice(0, 4).toUpperCase())}</span>`}<span>${esc(f.name)}</span>${i != null ? `<button data-rm="${i}" aria-label="Retirer">✕</button>` : ''}</span>`;
  }
  function renderAtt() { el.att.innerHTML = files.map((f, i) => attChip(f, i)).join(''); }
  el.att.addEventListener('click', e => { const b = e.target.closest('[data-rm]'); if (b) { files.splice(+b.dataset.rm, 1); renderAtt(); } });

  async function addFiles(list) {
    for (const f of list) {
      try {
        if (f.type.startsWith('image/')) files.push({ name: f.name || 'image.png', type: 'image/jpeg', data: await shrink(f) });
        else if (f.size > 400e3) toast(`${f.name} : trop gros (max 400 Ko pour un texte)`);
        else if (/^(text\/|application\/(json|xml|javascript))/.test(f.type) || /\.(md|txt|csv|json|js|ts|py|html|css|xml|yml|yaml|sql|php|java|c|cpp|rs|go|sh)$/i.test(f.name)) files.push({ name: f.name, type: f.type || 'text/plain', text: await f.text() });
        else toast(`${f.name} : format non pris en charge (images et textes uniquement)`);
      } catch (e) { toast('Lecture impossible : ' + f.name); }
    }
    renderAtt();
  }
  function shrink(file) {
    return new Promise((res, rej) => {
      const img = new Image(); const url = URL.createObjectURL(file);
      img.onload = () => {
        const k = Math.min(1, 1568 / Math.max(img.width, img.height));
        const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.86));
      };
      img.onerror = rej; img.src = url;
    });
  }
  $('#file').addEventListener('change', e => { addFiles([...e.target.files]); e.target.value = ''; });
  el.input.addEventListener('paste', e => { const fl = [...(e.clipboardData && e.clipboardData.files || [])]; if (fl.length) { e.preventDefault(); addFiles(fl); } });
  const comp = $('#composer');
  ['dragenter', 'dragover'].forEach(t => comp.addEventListener(t, e => { e.preventDefault(); comp.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach(t => comp.addEventListener(t, e => { e.preventDefault(); comp.classList.remove('drag'); }));
  comp.addEventListener('drop', e => addFiles([...e.dataTransfer.files]));

  /* ---------- Voix ---------- */
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null;
  $('#btn-voice').onclick = () => {
    const b = $('#btn-voice');
    if (!SR) return toast('Dictée non disponible dans ce navigateur (essaie Chrome ou Edge)');
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.lang = 'fr-FR'; rec.interimResults = true; rec.continuous = true;
    const base = el.input.value ? el.input.value.replace(/\s*$/, ' ') : '';
    rec.onresult = ev => { let t = ''; for (let i = 0; i < ev.results.length; i++) t += ev.results[i][0].transcript; el.input.value = base + t; autosize(); };
    rec.onend = () => { rec = null; b.classList.remove('rec'); b.textContent = 'Voix'; };
    rec.onerror = ev => { if (ev.error === 'not-allowed') toast('Autorise le micro pour dicter'); };
    rec.start(); b.classList.add('rec'); b.textContent = 'Stop';
  };
  function speak(text, btn) {
    if (!window.speechSynthesis) return toast('Lecture vocale non disponible');
    if (speechSynthesis.speaking) { speechSynthesis.cancel(); return; }
    const plain = text.replace(/```[\s\S]*?```/g, ' (bloc de code) ').replace(/[#*_`>|-]/g, ' ');
    const u = new SpeechSynthesisUtterance(plain); u.lang = 'fr-FR'; u.rate = 1.03;
    const v = speechSynthesis.getVoices().find(x => x.lang.startsWith('fr')); if (v) u.voice = v;
    speechSynthesis.speak(u); toast('Lecture… (re-clique pour arrêter)');
  }

  /* ---------- Puces du haut ---------- */
  function refreshChips() {
    const st = Store.settings;
    const dot = $('#chip-model .dot-live');
    if (arenaOn) {
      $('#chip-model-label').textContent = 'Arène : ' + st.arenaModels.slice(0, 3).map(m => labelOf(m).replace(/^Claude |Lilia Démo · /, '')).join(' · ');
      dot.className = 'dot-live';
    } else {
      $('#chip-model-label').textContent = labelOf(st.model);
      const [p] = AI.split(st.model); dot.className = 'dot-live' + (p === 'demo' ? ' demo' : Store.keys[p] ? ' ok' : '');
    }
    const role = Store.roles.find(r => r.id === st.roleId);
    $('#chip-role-label').textContent = role ? 'Rôle : ' + role.short : 'Sans rôle';
    $('#chip-role').classList.toggle('on', !!role);
    $('#chip-arena').classList.toggle('on', arenaOn);
    updateCost();
  }
  function updateStart() { $('#start-free').hidden = Object.keys(Store.keys).length > 0; }
  function updateCost() {
    updateStart();
    const st = Store.settings; const c = Store.monthCost();
    $('#cost-live').textContent = `${money(c)} ce mois${st.budget ? ' · budget ' + money(st.budget) : ''}`;
    $('#cost-live').style.color = st.budget && c >= st.budget ? 'var(--ruby)' : '';
  }
  $('#chip-model').onclick = () => openModels();
  $('#chip-role').onclick = () => openRoles();
  $('#chip-arena').onclick = () => toggleArena();
  $('#chip-cmd').onclick = () => openPalette();
  function toggleArena(force) {
    arenaOn = force != null ? force : !arenaOn; refreshChips();
    toast(arenaOn ? 'Arène activée : ta prochaine question part vers 3 IA' : 'Arène désactivée');
  }

  /* ---------- Fenêtres ---------- */
  function modal(html, onReady) {
    el.mi.innerHTML = html;
    if (!el.modal.open) el.modal.showModal();
    el.mi.querySelectorAll('[data-close]').forEach(b => b.onclick = () => el.modal.close());
    onReady && onReady(el.mi);
  }
  el.modal.addEventListener('click', e => { if (e.target === el.modal) el.modal.close(); });
  const head = (t, sub) => `<div class="m-head"><h2>${t}</h2><button class="icon-btn" data-close aria-label="Fermer">✕</button></div>${sub ? `<p class="m-sub">${sub}</p>` : ''}`;

  // Modèles
  async function openModels(tab) {
    const st = Store.settings;
    const provs = Object.keys(P);
    tab = tab || (arenaOn ? AI.split(st.arenaModels[0])[0] : AI.split(st.model)[0]);
    const draw = async () => {
      modal(head(arenaOn ? 'Modèles de l\'Arène' : 'Choisir un modèle', arenaOn ? 'Coche jusqu\'à 3 modèles. Tu peux mélanger les fournisseurs.' : 'Les listes viennent en direct de chaque fournisseur : toujours à jour.') +
        `<div class="tabs">${provs.map(p => `<button data-tab="${p}" class="${p === tab ? 'on' : ''}">${P[p].short}${Store.keys[p] || p === 'demo' ? '' : ' ·'}</button>`).join('')}</div>
         <input class="inp" id="mf" placeholder="Filtrer…" style="margin-bottom:10px"><div class="models-pick" id="ml"><p class="hint">Chargement…</p></div>
         ${arenaOn ? '<div class="row" style="margin-top:14px"><span class="hint" id="acount"></span><button class="btn" data-close style="margin-left:auto">Valider</button></div>' : ''}`);
      el.mi.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { tab = b.dataset.tab; draw(); });
      const ml = $('#ml');
      if (tab !== 'demo' && tab !== 'openrouter' && !Store.keys[tab]) {
        ml.innerHTML = `<div class="prov"><p class="hint">Pour utiliser <b>${P[tab].name}</b>, ajoute ta clé API${P[tab].freeKey ? ' (<b>gratuite</b>)' : ''}. Elle reste dans ton navigateur.</p><div class="row" style="margin-top:10px"><button class="btn sm" id="gokey">Ajouter ma clé</button><a class="btn ghost sm" href="${P[tab].keyUrl}" target="_blank" rel="noopener">Obtenir une clé ↗</a></div></div>`;
        $('#gokey').onclick = () => openSettings('keys');
        return;
      }
      const list = await AI.listModels(tab);
      AI.listModels.cache = AI.listModels.cache || {}; AI.listModels.cache[tab] = list;
      const paint = () => {
        const q = ($('#mf').value || '').toLowerCase(); const s = Store.settings;
        const items = list.filter(m => !q || (m.id + m.name).toLowerCase().includes(q)).slice(0, 250);
        ml.innerHTML = items.map(m => {
          const full = tab + ':' + m.id; const on = arenaOn ? s.arenaModels.includes(full) : s.model === full;
          const pr = AI.priceOf(tab, m.id);
          return `<button class="mp${on ? ' on' : ''}" data-m="${esc(full)}">${arenaOn ? `<input type="checkbox" ${on ? 'checked' : ''} tabindex="-1">` : ''}<span class="tx"><b>${esc(m.name)}</b><span>${esc(m.id)}${tab === 'demo' ? ' · gratuit' : pr ? ` · ≈ ${pr.in.toFixed(2)} / ${pr.out.toFixed(2)} $ par M jetons` : ''}</span></span></button>`;
        }).join('') || '<p class="hint">Aucun modèle.</p>';
        if (arenaOn) $('#acount').textContent = `${s.arenaModels.length} / 3 sélectionnés`;
      };
      paint();
      $('#mf').oninput = paint;
      ml.onclick = e => {
        const b = e.target.closest('[data-m]'); if (!b) return;
        const full = b.dataset.m;
        if (arenaOn) {
          let a = Store.settings.arenaModels.slice();
          if (a.includes(full)) { if (a.length > 2) a = a.filter(x => x !== full); else return toast('Garde au moins 2 modèles'); }
          else { if (a.length >= 3) a.shift(); a.push(full); }
          Store.saveSettings({ arenaModels: a }); paint(); refreshChips();
        } else { Store.saveSettings({ model: full }); refreshChips(); el.modal.close(); toast('Modèle : ' + labelOf(full)); }
      };
    };
    draw();
  }

  // Rôles
  function openRoles() {
    const draw = () => {
      const st = Store.settings; const roles = Store.roles;
      modal(head('Rôles', 'Un rôle donne une personnalité et une expertise à l\'IA pour toute la session.') +
        `<div class="list"><button class="li${!st.roleId ? ' on' : ''}" data-use=""><span class="em">–</span><span class="tx"><b>Sans rôle</b><span>Lilia, assistante polyvalente</span></span></button>
        ${roles.map(r => `<div class="li${st.roleId === r.id ? ' on' : ''}"><span class="em">${esc(r.short[0] || '?')}</span><span class="tx" data-use="${r.id}" style="cursor:pointer"><b>${esc(r.name)}</b><span>${esc(r.prompt)}</span></span><button class="btn ghost sm" data-edit="${r.id}">Modifier</button></div>`).join('')}</div>
        <div class="row" style="margin-top:14px"><button class="btn" data-edit="new">+ Nouveau rôle</button></div>`, m => {
        m.querySelectorAll('[data-use]').forEach(b => b.onclick = () => { Store.saveSettings({ roleId: b.dataset.use || null }); refreshChips(); el.modal.close(); });
        m.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editRole(b.dataset.edit));
      });
    };
    const editRole = id => {
      const roles = Store.roles; const r = id === 'new' ? { id: Store.uid(), name: '', short: '', prompt: '' } : roles.find(x => x.id === id);
      modal(head(id === 'new' ? 'Nouveau rôle' : 'Modifier le rôle') +
        `<div class="field"><label>Nom</label><input class="inp" id="rn" value="${esc(r.name)}" placeholder="Ex. Coach sportif"></div>
         <div class="field"><label>Nom court (affiché en haut)</label><input class="inp" id="rs" value="${esc(r.short)}" maxlength="16" placeholder="Coach"></div>
         <div class="field"><label>Instructions</label><textarea class="inp" id="rp" rows="6" placeholder="Tu es…">${esc(r.prompt)}</textarea></div>
         <div class="row"><button class="btn" id="rsave">Enregistrer</button><button class="btn ghost" id="rback">Retour</button>${id !== 'new' ? '<button class="btn ghost" id="rdel" style="margin-left:auto">Supprimer</button>' : ''}</div>`, () => {
        $('#rback').onclick = draw;
        $('#rsave').onclick = () => {
          r.name = $('#rn').value.trim(); r.short = $('#rs').value.trim() || r.name.split(' ')[0]; r.prompt = $('#rp').value.trim();
          if (!r.name || !r.prompt) return toast('Nom et instructions obligatoires');
          if (id === 'new') roles.push(r); Store.saveRoles(roles); refreshChips(); draw();
        };
        if ($('#rdel')) $('#rdel').onclick = () => { Store.saveRoles(roles.filter(x => x.id !== id)); if (Store.settings.roleId === id) Store.saveSettings({ roleId: null }); refreshChips(); draw(); };
      });
    };
    draw();
  }

  // Prompts
  function openPrompts() {
    const draw = () => {
      const ps = Store.prompts;
      modal(head('Mes prompts', 'Tape <b>/</b> dans la zone de saisie pour les appeler. Les <b>{{champs}}</b> sont à remplacer.') +
        `<div class="list">${ps.map(p => `<div class="li"><span class="em" style="font-family:JB;font-size:11px">/</span><span class="tx" data-use="${p.id}" style="cursor:pointer"><b>/${esc(p.cmd)} · ${esc(p.title)}</b><span>${esc(p.text)}</span></span><button class="btn ghost sm" data-edit="${p.id}">Modifier</button></div>`).join('')}</div>
         <div class="row" style="margin-top:14px"><button class="btn" data-edit="new">+ Nouveau prompt</button><button class="btn ghost" id="go5">Construire en 5 rubriques</button></div>`, m => {
        m.querySelectorAll('[data-use]').forEach(b => b.onclick = () => { el.modal.close(); usePrompt(ps.find(p => p.id === b.dataset.use)); });
        m.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editPrompt(b.dataset.edit));
        $('#go5').onclick = openFive;
      });
    };
    const editPrompt = (id, preset) => {
      const ps = Store.prompts; const p = id === 'new' ? Object.assign({ id: Store.uid(), cmd: '', title: '', text: '' }, preset) : ps.find(x => x.id === id);
      modal(head(id === 'new' ? 'Nouveau prompt' : 'Modifier le prompt') +
        `<div class="grid2"><div class="field"><label>Commande (après /)</label><input class="inp" id="pc" value="${esc(p.cmd)}" placeholder="ex. recette"></div><div class="field"><label>Titre</label><input class="inp" id="pt" value="${esc(p.title)}"></div></div>
         <div class="field"><label>Texte <span class="hint">Utilise {{champ}} pour les parties à remplir</span></label><textarea class="inp" id="px" rows="8">${esc(p.text)}</textarea></div>
         <div class="row"><button class="btn" id="psave">Enregistrer</button><button class="btn ghost" id="pback">Retour</button>${id !== 'new' ? '<button class="btn ghost" id="pdel" style="margin-left:auto">Supprimer</button>' : ''}</div>`, () => {
        $('#pback').onclick = draw;
        $('#psave').onclick = () => {
          p.cmd = $('#pc').value.trim().toLowerCase().replace(/[^a-z0-9àâäéèêëïîôöùûüç-]/g, ''); p.title = $('#pt').value.trim(); p.text = $('#px').value.trim();
          if (!p.cmd || !p.text) return toast('Commande et texte obligatoires');
          if (ps.some(x => x.cmd === p.cmd && x.id !== p.id)) return toast('Cette commande existe déjà');
          if (id === 'new') ps.push(p); Store.savePrompts(ps); draw();
        };
        if ($('#pdel')) $('#pdel').onclick = () => { Store.savePrompts(ps.filter(x => x.id !== id)); draw(); };
      });
    };
    openPrompts.edit = editPrompt;
    draw();
  }

  // 5 rubriques
  function openFive() {
    const R = [['Objectif', 'Que veux-tu obtenir ? Pour qui ?', 'Ex. une page de vente pour mes t-shirts GEN X'], ['Fonctionnalités', 'Ce que ça doit contenir ou faire', 'Ex. galerie, prix, bouton commander'], ['Style', 'Ton, design, couleurs, ambiance', 'Ex. sombre, néon rétro 80s, fun'], ['Contraintes', 'Ce qu\'il faut éviter ou respecter', 'Ex. mobile d\'abord, pas de smiley, en français'], ['Format de sortie', 'Comment tu veux le résultat', 'Ex. un seul fichier HTML / un tableau / 3 versions']];
    modal(head('Prompt en 5 rubriques', 'La méthode simple pour des résultats nets. Remplis ce que tu veux, Lilia assemble.') +
      `<div class="five">${R.map((r, i) => `<div class="field"><label><span><span class="n">0${i + 1} · </span>${r[0]}</span><span class="hint">${r[1]}</span></label><textarea class="inp" rows="2" id="f${i}" placeholder="${esc(r[2])}"></textarea></div>`).join('')}</div>
       <div class="row"><button class="btn" id="fuse">Mettre dans la saisie</button><button class="btn ghost" id="fsave">Enregistrer comme prompt</button></div>`, () => {
      const build = () => R.map((r, i) => [r[0], $('#f' + i).value.trim()]).filter(x => x[1]).map(([k, v]) => `## ${k}\n${v}`).join('\n\n');
      $('#fuse').onclick = () => { const t = build(); if (!t) return toast('Remplis au moins une rubrique'); el.modal.close(); el.input.value = t; autosize(); el.input.focus(); };
      $('#fsave').onclick = () => { const t = build(); if (!t) return toast('Remplis au moins une rubrique'); openPrompts(); openPrompts.edit('new', { text: t, title: ($('#f0') ? '' : '') }); };
    });
    setTimeout(() => $('#f0') && $('#f0').focus(), 50);
  }

  // Statistiques
  function openStats() {
    const u = Store.usage; const st = Store.settings;
    const days = [...Array(14)].map((_, i) => { const d = new Date(Date.now() - (13 - i) * 864e5).toISOString().slice(0, 10); return [d, u[d] || { msgs: 0, cost: 0, models: {} }]; });
    const max = Math.max(1, ...days.map(d => d[1].msgs));
    const month = Store.monthCost();
    const tot = Object.values(u).reduce((a, d) => ({ msgs: a.msgs + d.msgs, in: a.in + d.in, out: a.out + d.out }), { msgs: 0, in: 0, out: 0 });
    const mods = {}; Object.values(u).forEach(d => Object.entries(d.models).forEach(([k, v]) => mods[k] = (mods[k] || 0) + v));
    const top = Object.entries(mods).sort((a, b) => b[1] - a[1]).slice(0, 5);
    const pct = st.budget ? Math.min(100, month / st.budget * 100) : 0;
    modal(head('Statistiques', 'Coûts estimés à partir des tarifs publics : la facture exacte est chez chaque fournisseur.') +
      `<div class="grid2"><div class="stat"><span class="k">CE MOIS</span><div class="big">${money(month)}</div>${st.budget ? `<div class="bar"><i style="width:${pct}%"></i></div><p class="hint" style="margin-top:6px">${Math.round(pct)} % du budget de ${money(st.budget)}</p>` : '<p class="hint">Pas de budget défini.</p>'}</div>
       <div class="stat"><span class="k">TOTAL</span><div class="big">${tot.msgs} <small>réponses</small></div><p class="hint">${(tot.in / 1000).toFixed(1).replace('.', ',')} k jetons envoyés · ${(tot.out / 1000).toFixed(1).replace('.', ',')} k reçus</p></div></div>
       <div class="stat" style="margin-top:10px"><span class="k">14 DERNIERS JOURS</span><div class="spark">${days.map(d => `<i style="height:${d[1].msgs / max * 100}%" title="${d[0]} : ${d[1].msgs} réponses"></i>`).join('')}</div><div class="spark-l">${days.map(d => `<span>${+d[0].slice(8)}</span>`).join('')}</div></div>
       <div class="stat" style="margin-top:10px"><span class="k">MODÈLES LES PLUS UTILISÉS</span>${top.length ? top.map(([k, v]) => `<div class="row" style="margin-top:8px;font-size:13.5px"><span style="flex:1">${esc(labelOf(k))}</span><span class="mono" style="color:var(--tx3)">${v}</span></div>`).join('') : '<p class="hint" style="margin-top:6px">Rien pour l\'instant.</p>'}</div>`);
  }

  // Réglages
  function openSettings(tab) {
    tab = tab || 'keys';
    const draw = () => {
      const st = Store.settings; const keys = Store.keys;
      let body = '';
      if (tab === 'keys') {
        body = `<p class="hint" style="margin-bottom:14px">Lilia Studio est <b>gratuit</b>. Tu utilises tes propres clés : elles restent <b>uniquement dans ce navigateur</b> et partent directement chez le fournisseur, jamais chez nous. <a href="#" id="kguide" style="color:var(--ruby2)">C'est quoi une clé API, combien ça coûte ?</a></p>` +
          Object.entries(P).filter(([p]) => p !== 'demo').map(([p, v]) => `<div class="prov"><div class="prov-h"><b>${v.name}</b>${v.freeKey ? '<span class="badge ruby">GRATUIT</span>' : ''}${keys[p] ? '<span class="badge ok">CONNECTÉ</span>' : '<span class="badge">AUCUNE CLÉ</span>'}<a class="hint" href="${v.keyUrl}" target="_blank" rel="noopener">Obtenir une clé ↗</a></div>
            <div class="row"><input class="inp" type="password" autocomplete="off" spellcheck="false" data-key="${p}" value="${esc(keys[p] || '')}" placeholder="${v.keyHint || 'Colle ta clé ici'}" style="flex:1;min-width:180px"><button class="btn ghost sm" data-test="${p}">Tester</button>${keys[p] ? `<button class="btn ghost sm" data-clear="${p}">Effacer</button>` : ''}</div></div>`).join('') +
          `<p class="hint">Astuce : sur un ordinateur partagé, efface tes clés après usage.</p>`;
      } else if (tab === 'prefs') {
        body = `<div class="field"><label>Créativité (température) <span class="mono">${st.temperature}</span></label><input type="range" min="0" max="1" step="0.1" value="${st.temperature}" id="s-temp" style="accent-color:var(--ruby)"></div>
          <div class="grid2"><div class="field"><label>Longueur max. des réponses (jetons)</label><input class="inp" type="number" min="256" max="64000" step="256" id="s-max" value="${st.maxTokens}"></div>
          <div class="field"><label>Budget mensuel ($, 0 = aucun)</label><input class="inp" type="number" min="0" step="1" id="s-bud" value="${st.budget}"></div></div>
          <div class="field"><label>Instructions permanentes (ajoutées à chaque conversation)</label><textarea class="inp" id="s-sys" rows="4" placeholder="Ex. Je suis Stéphane, en Belgique. Réponds court et direct.">${esc(st.system)}</textarea></div>
          <label class="switch"><input type="checkbox" id="s-art" ${st.autoArtifact ? 'checked' : ''}> Ouvrir automatiquement l'aperçu quand l'IA crée une page</label>
          <div class="row" style="margin-top:16px"><button class="btn" id="s-save">Enregistrer</button></div>`;
      } else {
        body = `<p class="hint" style="margin-bottom:14px">Tes sessions, rôles et prompts sont stockés dans ce navigateur. Sauvegarde-les pour les retrouver ailleurs. <b>Les clés API ne sont jamais exportées.</b></p>
          <div class="row"><button class="btn" id="d-exp">Exporter (.json)</button><label class="btn ghost" style="cursor:pointer">Importer<input type="file" id="d-imp" accept=".json,application/json" hidden></label><button class="btn ghost" id="d-wipe" style="margin-left:auto">Tout effacer</button></div>
          <p class="hint" style="margin-top:18px">Lilia Studio 2 · application gratuite par <b>liliaa.tech</b>. Inspiré des meilleurs studios IA, dont Kiro de la communauté Renaud Dékode. Merci à eux.</p>`;
      }
      modal(head('Réglages') + `<div class="tabs"><button data-t="keys" class="${tab === 'keys' ? 'on' : ''}">Clés API</button><button data-t="prefs" class="${tab === 'prefs' ? 'on' : ''}">Préférences</button><button data-t="data" class="${tab === 'data' ? 'on' : ''}">Données</button></div>` + body, m => {
        m.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; draw(); });
        if ($('#kguide')) $('#kguide').onclick = e => { e.preventDefault(); openGuide(); };
        m.querySelectorAll('[data-key]').forEach(i => i.onchange = async () => { Store.setKey(i.dataset.key, i.value); Store.modelCache(i.dataset.key, []); draw(); toast(i.value ? 'Clé enregistrée dans ce navigateur' : 'Clé effacée'); if (i.value) await adoptProvider(i.dataset.key); refreshChips(); });
        m.querySelectorAll('[data-clear]').forEach(b => b.onclick = () => { Store.setKey(b.dataset.clear, ''); refreshChips(); draw(); });
        m.querySelectorAll('[data-test]').forEach(b => b.onclick = async () => {
          const p = b.dataset.test; const inp = m.querySelector(`[data-key="${p}"]`);
          if (inp.value.trim() !== (Store.keys[p] || '')) Store.setKey(p, inp.value);
          if (!Store.keys[p]) return toast('Colle d\'abord ta clé');
          b.textContent = '…';
          try {
            const r = await AI.chat({ model: p + ':' + (await AI.listModels(p, true))[0].id, messages: [{ role: 'user', content: 'Réponds juste : OK' }], maxTokens: 16, temperature: 0 });
            b.textContent = 'OK ✓'; toast(`${P[p].short} fonctionne (${r.ms} ms)`);
          } catch (e) { b.textContent = 'Échec'; toast(e.message, 6000); }
        });
        if (tab === 'prefs') {
          $('#s-temp').oninput = e => e.target.closest('.field').querySelector('.mono').textContent = e.target.value;
          $('#s-save').onclick = () => {
            Store.saveSettings({ temperature: +$('#s-temp').value, maxTokens: Math.max(256, +$('#s-max').value || 4096), budget: Math.max(0, +$('#s-bud').value || 0), system: $('#s-sys').value.trim(), autoArtifact: $('#s-art').checked });
            refreshChips(); toast('Préférences enregistrées');
          };
        }
        if (tab === 'data') {
          $('#d-exp').onclick = () => download('lilia-studio-sauvegarde-' + new Date().toISOString().slice(0, 10) + '.json', Store.exportAll(), 'application/json');
          $('#d-imp').onchange = async e => { try { Store.importAll(await e.target.files[0].text()); toast('Importé'); setTimeout(() => location.reload(), 600); } catch (x) { toast('Import impossible : ' + x.message); } };
          $('#d-wipe').onclick = () => { if (confirm('Effacer toutes tes sessions, rôles, prompts ET clés de ce navigateur ? C\'est définitif.')) { Store.wipe(); location.reload(); } };
        }
      });
    };
    draw();
  }

  /* Quand on ajoute une clé : si le modèle actuel n'est pas utilisable, on bascule sur le meilleur modèle de ce fournisseur */
  async function adoptProvider(p) {
    const [cp] = AI.split(Store.settings.model);
    if (cp !== 'demo' && Store.keys[cp]) return;
    try {
      const id = await AI.bestModel(p);
      AI.listModels.cache[p] = Store.modelCache(p) ? Store.modelCache(p).list : P[p].defaults;
      if (id) { Store.saveSettings({ model: p + ':' + id }); refreshChips(); toast('Modèle actif : ' + labelOf(p + ':' + id)); }
    } catch (e) { /* on garde le modèle actuel */ }
  }


  // Guide : comprendre les clés API
  function openGuide(sec) {
    const steps = {
      gemini: ['Va sur <b>aistudio.google.com</b> et connecte-toi avec ton compte Google.', 'Clique sur <b>Get API key</b> puis <b>Create API key</b>.', 'Copie la clé (elle commence par <b>AIza</b>) et colle-la dans Lilia.'],
      anthropic: ['Va sur <b>console.anthropic.com</b> et crée un compte (différent de ton abonnement claude.ai).', 'Dans <b>Billing</b>, ajoute des crédits prépayés (ex. 5 $) et règle une limite de dépense.', 'Dans <b>API Keys</b>, clique <b>Create Key</b>, copie la clé <b>sk-ant-…</b> et colle-la dans Lilia.'],
      openrouter: ['Va sur <b>openrouter.ai</b> et crée un compte gratuit.', 'Dans <b>Keys</b>, clique <b>Create Key</b> et copie la clé <b>sk-or-…</b>.', 'Dans Lilia, choisis un modèle dont le nom finit par <b>:free</b>.'],
      mistral: ['Va sur <b>console.mistral.ai</b> et crée un compte.', 'Choisis l\'offre gratuite <b>Experiment</b> (tes échanges peuvent servir à entraîner leurs modèles).', 'Dans <b>API Keys</b>, crée une clé et colle-la dans Lilia.'],
      openai: ['Va sur <b>platform.openai.com</b> (différent de ton abonnement ChatGPT).', 'Dans <b>Billing</b>, ajoute des crédits prépayés et une limite.', 'Dans <b>API keys</b>, crée une clé <b>sk-…</b> et colle-la dans Lilia.']
    };
    const card = (p, title, price, note) => `<details class="prov" ${sec === p ? 'open' : ''}><summary class="prov-h" style="cursor:pointer;margin:0"><b>${title}</b>${price}</summary>
      <p class="hint" style="margin:10px 0 8px">${note}</p><ol style="padding-left:1.2em;font-size:14px;line-height:1.6">${steps[p].map(s => `<li>${s}</li>`).join('')}</ol>
      <div class="row" style="margin-top:10px"><a class="btn sm" href="${P[p].keyUrl}" target="_blank" rel="noopener">Obtenir la clé ↗</a><button class="btn ghost sm" data-gokeys>Coller ma clé</button></div></details>`;
    modal(head('Comprendre les clés API', 'En 2 minutes : ce que c\'est, quelle IA pour quoi, combien ça coûte, comment en obtenir une.') + `
      <div class="five">
        <div class="stat"><span class="k">01 · C'EST QUOI ?</span>
          <p style="margin-top:8px">Une <b>clé API</b>, c'est ton <b>badge personnel</b> chez une IA (Claude, Gemini…). Lilia Studio est la belle interface ; la clé permet à cette interface de parler directement à l'IA, <b>en ton nom</b>.</p>
          <p class="hint" style="margin-top:8px">Ta clé reste uniquement dans ton navigateur et part directement chez le fournisseur. Lilia ne la voit jamais et ne prend aucune commission.</p></div>
        <div class="stat"><span class="k">02 · COMMENT ON PAIE ?</span>
          <p style="margin-top:8px">C'est comme un <b>compteur d'électricité</b> : tu paies ce que tu consommes, en <b>jetons</b> (des morceaux de mots). 1 million de jetons ≈ 750 000 mots, soit plusieurs gros livres.</p>
          <p style="margin-top:8px">Un échange normal (une question + une réponse) coûte en général <b>autour d'un centime</b> avec un modèle comme Claude Sonnet. Les modèles « mini », « flash » ou « haiku » coûtent encore beaucoup moins.</p>
          <p class="hint" style="margin-top:8px"><b>Attention :</b> ton abonnement claude.ai ou ChatGPT Plus <b>ne donne pas</b> de clé API. Ce sont deux services séparés.</p></div>
        <div class="stat"><span class="k">03 · UNE IA N'EST PAS L'AUTRE</span>
          <p style="margin-top:8px">Chaque IA a sa personnalité et ses points forts. Gratuit ne veut pas dire « pareil » : choisis selon ce que tu veux faire.</p>
          <div class="list" style="margin-top:10px">
            <div class="li"><span class="em">C</span><span class="tx"><b>Claude</b><span style="white-space:normal">Écriture naturelle, code, longs documents, raisonnement nuancé. Le plus fiable pour créer des pages et des applis.</span></span></div>
            <div class="li"><span class="em">G</span><span class="tx"><b>Gemini</b><span style="white-space:normal">Très rapide, avale de très longs textes et des images, idéal pour résumer, chercher et analyser. Parfait pour débuter gratuitement.</span></span></div>
            <div class="li"><span class="em">O</span><span class="tx"><b>ChatGPT</b><span style="white-space:normal">Le généraliste le plus connu, à l'aise dans beaucoup de domaines.</span></span></div>
            <div class="li"><span class="em">M</span><span class="tx"><b>Mistral</b><span style="white-space:normal">L'IA d'une entreprise française : rapide, très bonne en français, un choix européen.</span></span></div>
            <div class="li"><span class="em">R</span><span class="tx"><b>OpenRouter</b><span style="white-space:normal">Pas une IA, mais une porte d'entrée vers des centaines de modèles, dont des gratuits, pour tester sans multiplier les comptes.</span></span></div>
          </div>
          <p class="hint" style="margin-top:10px"><b>Le bon réflexe :</b> pose la même question dans l'<b>Arène</b> et compare les 3 réponses côte à côte. Tu verras vite laquelle te convient pour chaque tâche.</p></div>
        <div class="stat"><span class="k">04 · LES OPTIONS ET LES PRIX</span>
          <div class="list" style="margin-top:10px">
          ${card('gemini', 'Gemini (Google)', '<span class="badge ok">GRATUIT</span>', 'Gratuit avec un quota de demandes par jour, sans carte bancaire. En version gratuite, Google peut utiliser tes échanges pour améliorer ses produits : n\'y mets rien de confidentiel.')}
          ${card('anthropic', 'Claude (Anthropic)', '<span class="badge ruby">PAYANT · PRÉPAYÉ</span>', 'La meilleure qualité pour écrire et coder. Pas d\'offre gratuite : tu recharges des crédits (quelques dollars suffisent pour commencer) et tu fixes une limite pour ne jamais dépasser.')}
          ${card('openrouter', 'OpenRouter', '<span class="badge ok">GRATUIT</span>', 'Une seule clé pour plus de 300 modèles. Les modèles marqués « :free » sont gratuits, avec une limite d\'environ 50 demandes par jour (plus si tu as déjà rechargé des crédits).')}
          ${card('mistral', 'Mistral (français)', '<span class="badge ok">GRATUIT</span>', 'L\'IA européenne. L\'offre gratuite « Experiment » est généreuse, en échange tes échanges peuvent servir à l\'entraînement.')}
          ${card('openai', 'ChatGPT (OpenAI)', '<span class="badge ruby">PAYANT · PRÉPAYÉ</span>', 'Même principe que Claude : crédits prépayés, limite de dépense recommandée.')}
          </div></div>
        <div class="stat"><span class="k">05 · LES 4 RÈGLES D'OR</span>
          <ol style="padding-left:1.2em;margin-top:8px;font-size:14px;line-height:1.7">
            <li>Ne partage <b>jamais</b> ta clé (ni en capture d'écran, ni par message).</li>
            <li>Chez les services payants, <b>fixe une limite de dépense</b> dès le départ.</li>
            <li>Une clé perdue ou montrée ? <b>Supprime-la</b> chez le fournisseur et crée-en une nouvelle.</li>
            <li>Dans Lilia, regarde le <b>compteur</b> en bas : il estime ce que tu dépenses ce mois-ci.</li>
          </ol></div>
        <p class="hint">Les prix et les quotas changent souvent : la page officielle de chaque fournisseur fait foi.</p>
      </div>`, m => { m.querySelectorAll('[data-gokeys]').forEach(b => b.onclick = () => openSettings('keys')); });
  }

  // Démarrer gratuitement : clé Gemini en 1 minute
  function openStart() {
    modal(head('Démarrer gratuitement', 'Google offre une clé Gemini gratuite, avec un quota chaque jour. Ça prend une minute, sans carte bancaire.') +
      `<div class="five">
        <div class="prov"><span class="k">ÉTAPE 1</span><p style="margin:6px 0 10px">Ouvre Google AI Studio et connecte-toi avec ton compte Google.</p><a class="btn sm" href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener">Ouvrir Google AI Studio ↗</a></div>
        <div class="prov"><span class="k">ÉTAPE 2</span><p style="margin:6px 0 0">Clique sur <b>Create API key</b> (ou « Créer une clé API »), puis copie la clé qui commence par <b>AIza</b>.</p></div>
        <div class="prov"><span class="k">ÉTAPE 3</span><p style="margin:6px 0 10px">Colle-la ici. Elle reste uniquement dans ton navigateur.</p>
          <div class="row"><input class="inp" id="sk" type="password" autocomplete="off" spellcheck="false" placeholder="AIza…" style="flex:1;min-width:180px"><button class="btn" id="sgo">C'est parti</button></div>
          <p class="hint" id="smsg" style="margin-top:8px"></p></div>
      </div>
      <p class="hint">Tu as une clé Claude, Mistral ou OpenRouter ? <a href="#" id="sother" style="color:var(--ruby2)">Ajoute-la dans Réglages</a> · <a href="#" id="sguide" style="color:var(--ruby2)">C'est quoi une clé API ?</a></p>`, () => {
      $('#sother').onclick = e => { e.preventDefault(); openSettings('keys'); };
      $('#sguide').onclick = e => { e.preventDefault(); openGuide('gemini'); };
      $('#sgo').onclick = async () => {
        const k = $('#sk').value.trim(); const msg = $('#smsg');
        if (!/^AIza/.test(k)) { msg.textContent = 'Une clé Gemini commence par « AIza ». Vérifie le copier-coller.'; return; }
        Store.setKey('gemini', k); Store.modelCache('gemini', []);
        msg.textContent = 'Vérification…';
        try {
          const id = await AI.bestModel('gemini');
          await AI.chat({ model: 'gemini:' + id, messages: [{ role: 'user', content: 'Réponds juste : OK' }], maxTokens: 16, temperature: 0 });
          AI.listModels.cache.gemini = Store.modelCache('gemini') ? Store.modelCache('gemini').list : P.gemini.defaults;
          Store.saveSettings({ model: 'gemini:' + id }); refreshChips(); el.modal.close();
          toast('Gemini est connecté. Écris ta première demande !', 4000); el.input.focus();
        } catch (e) { msg.textContent = 'La clé ne fonctionne pas : ' + e.message; }
      };
      setTimeout(() => $('#sk').focus(), 50);
    });
  }
  $('#start-free').onclick = openStart;
  $('#home-guide').onclick = e => { e.preventDefault(); openGuide(); };

  /* ---------- Palette Ctrl K ---------- */
  const pal = $('#palette'), palIn = $('#pal-input'), palList = $('#pal-list');
  let palSel = 0, palItems = [];
  function commands() {
    const c = [
      ['Nouvelle session', 'Session', newSession],
      ['Démarrer gratuitement (clé Gemini)', 'IA', openStart],
      ['Comprendre les clés API et les prix', 'Aide', () => openGuide()],
      ['Choisir le modèle', 'IA', () => openModels()],
      [arenaOn ? 'Désactiver l\'Arène' : 'Activer l\'Arène (3 IA)', 'IA', () => toggleArena()],
      ['Choisir un rôle', 'IA', openRoles],
      ['Prompt en 5 rubriques', 'Prompt', openFive],
      ['Mes prompts', 'Prompt', openPrompts],
      ['Statistiques et budget', 'Outils', openStats],
      ['Clés API', 'Réglages', () => openSettings('keys')],
      ['Préférences', 'Réglages', () => openSettings('prefs')],
      ['Exporter mes données', 'Réglages', () => download('lilia-studio-sauvegarde.json', Store.exportAll(), 'application/json')],
      ['Dictée vocale', 'Outils', () => $('#btn-voice').click()]
    ];
    if (cur) c.push(['Exporter cette session en Markdown', 'Session', exportSession]);
    if (artifact.html) c.push(['Rouvrir le dernier artefact', 'Artefact', () => openArtifact(artifact.html)]);
    Store.prompts.forEach(p => c.push(['/' + p.cmd + ' · ' + p.title, 'Prompt', () => usePrompt(p)]));
    sessions.slice(0, 20).forEach(s => c.push([s.title, 'Ouvrir', () => openSession(s.id)]));
    return c;
  }
  function openPalette() { pal.hidden = false; palIn.value = ''; palDraw(); palIn.focus(); }
  function closePalette() { pal.hidden = true; }
  function palDraw() {
    const q = palIn.value.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
    palItems = commands().filter(c => c[0].toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').includes(q)).slice(0, 40);
    palSel = Math.min(palSel, Math.max(0, palItems.length - 1));
    palList.innerHTML = palItems.map((c, i) => `<button class="pal-it${i === palSel ? ' on' : ''}" data-i="${i}">${esc(c[0])}<span class="g">${c[1]}</span></button>`).join('') || '<p class="hint" style="padding:12px">Aucune commande.</p>';
  }
  palIn.addEventListener('input', () => { palSel = 0; palDraw(); });
  palIn.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { palSel = (palSel + 1) % palItems.length; palDraw(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { palSel = (palSel - 1 + palItems.length) % palItems.length; palDraw(); e.preventDefault(); }
    else if (e.key === 'Enter' && palItems[palSel]) { const f = palItems[palSel][2]; closePalette(); f(); }
    else if (e.key === 'Escape') closePalette();
  });
  palList.addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (b) { const f = palItems[+b.dataset.i][2]; closePalette(); f(); } });
  pal.addEventListener('click', e => { if (e.target === pal) closePalette(); });

  function exportSession() {
    const t = `# ${cur.title}\n\n` + cur.messages.map(m => `### ${m.role === 'user' ? 'Moi' : labelOf(m.model)}\n\n${m.content}`).join('\n\n---\n\n');
    download(cur.title.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-').toLowerCase() + '.md', t, 'text/markdown');
  }

  /* ---------- Raccourcis & navigation ---------- */
  document.addEventListener('keydown', e => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); pal.hidden ? openPalette() : closePalette(); }
    else if (mod && e.key.toLowerCase() === 'n' && !e.shiftKey) { e.preventDefault(); newSession(); }
    else if (e.key === 'Escape' && !pal.hidden) closePalette();
    else if (e.key === 'Escape' && busy) busy.abort();
  });
  $$('[data-open]').forEach(b => b.addEventListener('click', () => openFrom(b.dataset.open)));
  el.thread.addEventListener('click', e => { const b = e.target.closest('[data-open]'); if (b) openFrom(b.dataset.open); });
  function openFrom(k) { closeSide(); ({ roles: openRoles, prompts: openPrompts, stats: openStats, settings: () => openSettings(), guide: () => openGuide() })[k](); }
  $('#btn-new').onclick = () => { newSession(); closeSide(); };
  $('#btn-5r').onclick = openFive;
  $('#side-open').onclick = () => { el.side.classList.add('open'); el.scrim.classList.add('show'); };
  function closeSide() { el.side.classList.remove('open'); el.scrim.classList.remove('show'); }
  $('#side-close').onclick = closeSide; el.scrim.onclick = closeSide;
  $('#cards').addEventListener('click', e => {
    const b = e.target.closest('[data-start]'); if (!b) return;
    const k = b.dataset.start;
    if (k === 'artefact') { el.input.value = 'Crée une page web pour {{ton idée}}, design sombre et moderne, avec une animation.'; autosize(); selectVar(); }
    else if (k === 'arena') { toggleArena(true); el.input.focus(); }
    else openFive();
  });

  /* ---------- Démarrage ---------- */
  renderSessions(); refreshChips(); autosize();
  // pré-charge les noms des modèles connus pour les étiquettes
  AI.listModels.cache = {};
  Object.keys(P).forEach(p => { const c = Store.modelCache(p); AI.listModels.cache[p] = (c && c.list && c.list.length ? c.list : P[p].defaults); });
  refreshChips();
  if (!Object.keys(Store.keys).length && !localStorage.getItem('ls2.welcomed')) {
    localStorage.setItem('ls2.welcomed', '1');
    setTimeout(() => toast('Bienvenue ! Clique sur « Démarrer gratuitement » pour une IA gratuite en 1 minute.', 5000), 700);
  }
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('sw.js').catch(() => {});
})();
