/* Lilia Studio 2 — fournisseurs d'IA (appels directs depuis le navigateur, en streaming) */
(function () {
  'use strict';

  /* ---------- Catalogue ---------- */
  const PROVIDERS = {
    anthropic: {
      name: 'Claude (Anthropic)', short: 'Claude', keyUrl: 'https://console.anthropic.com/settings/keys', keyHint: 'sk-ant-…',
      defaults: [
        { id: 'claude-sonnet-5-5', name: 'Claude Sonnet 5.5' },
        { id: 'claude-opus-5-5', name: 'Claude Opus 5.5' },
        { id: 'claude-haiku-5-5', name: 'Claude Haiku 5.5' }
      ]
    },
    gemini: {
      name: 'Gemini (Google)', short: 'Gemini', keyUrl: 'https://aistudio.google.com/app/apikey', keyHint: 'AIza…', freeKey: true,
      defaults: [{ id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash' }, { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro' }]
    },
    openrouter: {
      name: 'OpenRouter (300+ modèles)', short: 'OpenRouter', keyUrl: 'https://openrouter.ai/keys', keyHint: 'sk-or-…', freeKey: true,
      defaults: [{ id: 'anthropic/claude-sonnet-5.5', name: 'Claude Sonnet 5.5 (via OpenRouter)' }]
    },
    mistral: {
      name: 'Mistral (Le Chat)', short: 'Mistral', keyUrl: 'https://console.mistral.ai/api-keys', keyHint: '', freeKey: true,
      defaults: [{ id: 'mistral-large-latest', name: 'Mistral Large' }, { id: 'mistral-small-latest', name: 'Mistral Small' }]
    },
    openai: {
      name: 'ChatGPT (OpenAI)', short: 'GPT', keyUrl: 'https://platform.openai.com/api-keys', keyHint: 'sk-…',
      defaults: [{ id: 'gpt-4o', name: 'GPT-4o' }, { id: 'gpt-4o-mini', name: 'GPT-4o mini' }]
    },
    demo: {
      name: 'Mode démo (sans clé)', short: 'Démo', keyUrl: '', free: true,
      defaults: [
        { id: 'lilia-demo', name: 'Lilia Démo · Claire' },
        { id: 'lilia-demo-vif', name: 'Lilia Démo · Vive' },
        { id: 'lilia-demo-poete', name: 'Lilia Démo · Poète' }
      ]
    }
  };

  /* Prix indicatifs en $ par million de jetons (estimation, à vérifier chez chaque fournisseur) */
  function priceOf(provider, model) {
    const m = (model || '').toLowerCase();
    if (provider === 'demo') return { in: 0, out: 0 };
    if (provider === 'openrouter') {
      const c = Store.modelCache('openrouter'); const f = c && c.list.find(x => x.id === model);
      if (f && f.price) return f.price;
    }
    if (m.includes('opus')) return { in: 5, out: 25 };
    if (m.includes('sonnet')) return { in: 3, out: 15 };
    if (m.includes('haiku')) return { in: 1, out: 5 };
    if (m.includes('nano')) return { in: 0.1, out: 0.4 };
    if (m.includes('mini')) return { in: 0.4, out: 1.6 };
    if (m.includes('flash')) return { in: 0.3, out: 2.5 };
    if (m.includes('gemini')) return { in: 1.25, out: 10 };
    if (m.includes('small') || m.includes('ministral')) return { in: 0.2, out: 0.6 };
    if (m.includes('mistral') || m.includes('large')) return { in: 2, out: 6 };
    return { in: 2.5, out: 10 };
  }
  const cost = (p, m, i, o) => { const pr = priceOf(p, m); return (i * pr.in + o * pr.out) / 1e6; };

  const split = full => { const i = full.indexOf(':'); return i < 0 ? ['demo', full] : [full.slice(0, i), full.slice(i + 1)]; };
  const approxTok = s => Math.ceil((s || '').length / 4);

  /* ---------- Liste des modèles (récupérée en direct chez le fournisseur) ---------- */
  async function listModels(p, force) {
    const def = PROVIDERS[p].defaults;
    const key = Store.keys[p];
    if (p === 'demo') return def;
    if (p !== 'openrouter' && !key) return def;
    const c = Store.modelCache(p);
    if (c && !force && Date.now() - c.t < 864e5) return c.list;
    try {
      let list = [];
      if (p === 'anthropic') {
        const r = await fetch('https://api.anthropic.com/v1/models?limit=100', { headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' } });
        if (!r.ok) throw new Error(r.status);
        list = (await r.json()).data.map(m => ({ id: m.id, name: m.display_name || m.id }));
      } else if (p === 'openai') {
        const r = await fetch('https://api.openai.com/v1/models', { headers: { Authorization: 'Bearer ' + key } });
        if (!r.ok) throw new Error(r.status);
        list = (await r.json()).data.map(m => m.id)
          .filter(id => /^(gpt|o\d|chatgpt)/.test(id) && !/(audio|realtime|transcribe|tts|image|search|embedding|instruct)/.test(id))
          .sort().reverse().map(id => ({ id, name: id }));
      } else if (p === 'gemini') {
        const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', { headers: { 'x-goog-api-key': key } });
        if (!r.ok) throw new Error(r.status);
        list = (await r.json()).models.filter(m => (m.supportedGenerationMethods || []).includes('generateContent') && /gemini/.test(m.name) && !/(embedding|tts|image|aqa)/.test(m.name))
          .map(m => ({ id: m.name.replace('models/', ''), name: m.displayName || m.name }));
      } else if (p === 'mistral') {
        const r = await fetch('https://api.mistral.ai/v1/models', { headers: { Authorization: 'Bearer ' + key } });
        if (!r.ok) throw new Error(r.status);
        const seen = new Set();
        list = (await r.json()).data.filter(m => !m.capabilities || m.capabilities.completion_chat !== false)
          .filter(m => !/(embed|moderation|ocr)/.test(m.id) && !seen.has(m.id) && seen.add(m.id)).map(m => ({ id: m.id, name: m.name || m.id }));
      } else if (p === 'openrouter') {
        const r = await fetch('https://openrouter.ai/api/v1/models');
        if (!r.ok) throw new Error(r.status);
        list = (await r.json()).data.map(m => ({
          id: m.id, name: m.name || m.id,
          price: m.pricing ? { in: +m.pricing.prompt * 1e6 || 0, out: +m.pricing.completion * 1e6 || 0 } : null
        }));
      }
      if (list.length) { Store.modelCache(p, list); return list; }
    } catch (e) { console.warn('Liste des modèles indisponible pour', p, e.message); }
    return c ? c.list : def;
  }

  /* ---------- Lecture d'un flux SSE ---------- */
  async function* sse(res, signal) {
    const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = '';
    while (true) {
      if (signal && signal.aborted) { reader.cancel(); return; }
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith('data:')) continue;
        const d = line.slice(5).trim();
        if (d === '[DONE]') return;
        try { yield JSON.parse(d); } catch { /* ligne partielle */ }
      }
    }
  }

  async function httpError(r, p) {
    let msg = '';
    try { const j = await r.json(); msg = (j.error && (j.error.message || j.error)) || j.message || JSON.stringify(j); } catch { msg = r.statusText; }
    const hints = { 401: 'Clé API refusée : vérifie-la dans Réglages.', 403: 'Accès refusé par le fournisseur.', 404: 'Modèle introuvable : choisis-en un autre.', 429: 'Trop de demandes ou crédit épuisé chez le fournisseur.', 529: 'Le service est surchargé, réessaie dans un instant.' };
    const e = new Error((hints[r.status] ? hints[r.status] + ' ' : '') + '(' + PROVIDERS[p].short + ' ' + r.status + ') ' + String(msg).slice(0, 220));
    e.status = r.status; return e;
  }

  /* ---------- Préparation des messages ---------- */
  const isImg = f => f.type && f.type.startsWith('image/') && f.data;
  const b64 = d => d.split(',')[1];
  function textWithFiles(m) {
    let t = m.content || '';
    (m.files || []).filter(f => f.text != null).forEach(f => { t += `\n\n--- Fichier joint : ${f.name} ---\n${f.text}`; });
    return t;
  }

  /* ---------- Envoi en streaming ---------- */
  // opts: { model:'prov:id', messages:[{role,content,files}], system, temperature, maxTokens, signal, onDelta(text) }
  async function chat(opts) {
    const [p, model] = split(opts.model);
    const key = Store.keys[p];
    if (p !== 'demo' && !key) { const e = new Error(`Ajoute ta clé ${PROVIDERS[p] ? PROVIDERS[p].short : p} dans Réglages pour utiliser ce modèle.`); e.needKey = p; throw e; }
    const t0 = performance.now(); let out = '', inTok = 0, outTok = 0;
    const push = t => { if (t) { out += t; opts.onDelta && opts.onDelta(t, out); } };
    const msgs = opts.messages; const sys = opts.system || '';
    const max = opts.maxTokens || 4096;

    if (p === 'demo') {
      await demo(model, msgs, push, opts.signal);
    } else if (p === 'anthropic') {
      const body = {
        model, max_tokens: max, stream: true,
        messages: msgs.map(m => ({
          role: m.role,
          content: m.role === 'user' && (m.files || []).some(isImg)
            ? [...m.files.filter(isImg).map(f => ({ type: 'image', source: { type: 'base64', media_type: f.type, data: b64(f.data) } })), { type: 'text', text: textWithFiles(m) || '.' }]
            : (textWithFiles(m) || '.')
        }))
      };
      if (sys) body.system = sys;
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST', signal: opts.signal,
        headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
        body: JSON.stringify(body)
      });
      if (!r.ok) throw await httpError(r, p);
      for await (const ev of sse(r, opts.signal)) {
        if (ev.type === 'message_start' && ev.message && ev.message.usage) inTok = ev.message.usage.input_tokens || 0;
        else if (ev.type === 'content_block_delta' && ev.delta && ev.delta.type === 'text_delta') push(ev.delta.text);
        else if (ev.type === 'message_delta' && ev.usage) outTok = ev.usage.output_tokens || outTok;
        else if (ev.type === 'error') throw new Error((ev.error && ev.error.message) || 'Erreur Claude');
      }
    } else if (p === 'gemini') {
      const body = {
        contents: msgs.map(m => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [...(m.files || []).filter(isImg).map(f => ({ inline_data: { mime_type: f.type, data: b64(f.data) } })), { text: textWithFiles(m) || '.' }]
        })),
        generationConfig: { temperature: opts.temperature, maxOutputTokens: max }
      };
      if (sys) body.systemInstruction = { parts: [{ text: sys }] };
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:streamGenerateContent?alt=sse`, {
        method: 'POST', signal: opts.signal, headers: { 'content-type': 'application/json', 'x-goog-api-key': key }, body: JSON.stringify(body)
      });
      if (!r.ok) throw await httpError(r, p);
      for await (const ev of sse(r, opts.signal)) {
        const c = ev.candidates && ev.candidates[0];
        if (c && c.content && c.content.parts) c.content.parts.forEach(x => { if (x.text && !x.thought) push(x.text); });
        if (ev.usageMetadata) { inTok = ev.usageMetadata.promptTokenCount || inTok; outTok = ev.usageMetadata.candidatesTokenCount || outTok; }
      }
    } else {
      // OpenAI, Mistral, OpenRouter : format compatible OpenAI
      const url = { openai: 'https://api.openai.com/v1/chat/completions', mistral: 'https://api.mistral.ai/v1/chat/completions', openrouter: 'https://openrouter.ai/api/v1/chat/completions' }[p];
      const messages = [];
      if (sys) messages.push({ role: 'system', content: sys });
      msgs.forEach(m => messages.push({
        role: m.role,
        content: m.role === 'user' && (m.files || []).some(isImg)
          ? [{ type: 'text', text: textWithFiles(m) || '.' }, ...m.files.filter(isImg).map(f => ({ type: 'image_url', image_url: { url: f.data } }))]
          : (textWithFiles(m) || '.')
      }));
      const body = { model, messages, stream: true };
      if (p === 'openai') { body.max_completion_tokens = max; body.stream_options = { include_usage: true }; }
      else { body.max_tokens = max; body.temperature = opts.temperature; }
      if (p === 'openrouter') body.usage = { include: true };
      const headers = { 'content-type': 'application/json', Authorization: 'Bearer ' + key };
      if (p === 'openrouter') { headers['HTTP-Referer'] = location.origin; headers['X-Title'] = 'Lilia Studio'; }
      const r = await fetch(url, { method: 'POST', signal: opts.signal, headers, body: JSON.stringify(body) });
      if (!r.ok) throw await httpError(r, p);
      for await (const ev of sse(r, opts.signal)) {
        if (ev.error) throw new Error(ev.error.message || 'Erreur fournisseur');
        const d = ev.choices && ev.choices[0] && ev.choices[0].delta;
        if (d && typeof d.content === 'string') push(d.content);
        if (ev.usage) { inTok = ev.usage.prompt_tokens || inTok; outTok = ev.usage.completion_tokens || outTok; }
      }
    }

    if (!inTok) inTok = approxTok(sys + msgs.map(textWithFiles).join(' '));
    if (!outTok) outTok = approxTok(out);
    const c = cost(p, model, inTok, outTok);
    return { text: out, inTok, outTok, cost: c, ms: Math.round(performance.now() - t0), provider: p, model };
  }

  /* ---------- Mode démo : réponses simulées, clairement signalées ---------- */
  const sleep = (ms, s) => new Promise((res, rej) => { const t = setTimeout(res, ms); s && s.addEventListener('abort', () => { clearTimeout(t); rej(new DOMException('stop', 'AbortError')); }, { once: true }); });
  async function stream(text, push, signal, speed) {
    const parts = text.match(/[\s\S]{1,6}/g) || [];
    for (const part of parts) { await sleep(speed, signal); push(part); }
  }
  const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function demoPage(topic, accent) {
    const t = esc(topic.slice(0, 60) || 'Ton idée');
    return `<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${t}</title>
<style>
*{box-sizing:border-box;margin:0}body{font-family:system-ui,sans-serif;background:#07070A;color:#EDEDF2;min-height:100vh;display:grid;place-items:center;overflow:hidden}
.g{position:fixed;inset:-40%;background:radial-gradient(closest-side,${accent}40,transparent 70%);animation:m 9s ease-in-out infinite alternate}
@keyframes m{to{transform:translate(18%,12%) scale(1.2)}}
main{position:relative;text-align:center;padding:32px;max-width:720px}
small{letter-spacing:.2em;color:${accent};font-size:12px}
h1{font-size:clamp(34px,7vw,64px);line-height:1.05;margin:14px 0}
p{color:#9a9aad;font-size:18px}
button{margin-top:28px;background:${accent};color:#fff;border:0;border-radius:12px;padding:14px 24px;font-size:16px;font-weight:700;cursor:pointer;transition:transform .2s}
button:hover{transform:translateY(-2px) scale(1.03)}
#n{display:block;margin-top:16px;color:#77778a;font-size:14px}
</style></head><body><div class="g"></div>
<main><small>CRÉÉ AVEC LILIA STUDIO</small><h1>${t}</h1><p>Une page générée en direct. Clique pour tester l'interactivité.</p>
<button id="b">C'est parti</button><span id="n">0 clic</span></main>
<script>let c=0;b.onclick=()=>{c++;n.textContent=c+(c>1?' clics':' clic');document.querySelector('.g').style.filter='hue-rotate('+c*40+'deg)'}</script>
</body></html>`;
  }

  async function demo(model, msgs, push, signal) {
    const last = [...msgs].reverse().find(m => m.role === 'user') || { content: '' };
    const q = (last.content || '').trim();
    const ql = q.toLowerCase();
    const sp = model === 'lilia-demo-vif' ? 8 : model === 'lilia-demo-poete' ? 22 : 14;
    await sleep(model === 'lilia-demo-vif' ? 250 : 500, signal);
    const wantsPage = /(page|site|landing|jeu|game|html|appli|app |mini-app|bouton|formulaire|calculat)/.test(ql);
    const note = "\n\n> **Mode démo** : cette réponse est simulée. Pour de vraies réponses : clique sur **Démarrer gratuitement** (clé Gemini gratuite, 1 minute) ou ajoute ta clé Claude dans **Réglages**.";
    let txt;
    if (wantsPage) {
      const accent = model === 'lilia-demo-vif' ? '#FF7A45' : model === 'lilia-demo-poete' ? '#B66BFF' : '#FF2E50';
      txt = `Voici une première version, prête à tester dans le panneau **Artefact** à droite.\n\n\`\`\`html\n${demoPage(q.replace(/^(crée|fais|génère|cree|fait)( moi)? (une?|la|le)?/i, '').trim() || q, accent)}\n\`\`\`\n\nTu peux me demander de changer les couleurs, d'ajouter des sections ou de rendre le bouton plus fun.` + note;
    } else if (model === 'lilia-demo-vif') {
      txt = `**En bref :** ${q ? '« ' + q.slice(0, 80) + ' »' : 'ta question'} — voici l'essentiel.\n\n1. Va droit au but\n2. Teste vite\n3. Ajuste\n\nOn passe à l'action ?` + note;
    } else if (model === 'lilia-demo-poete') {
      txt = `*Une idée naît comme une étincelle dans l'obsidienne…*\n\n${q ? 'Tu me parles de « ' + q.slice(0, 80) + ' ».' : ''} Laisse-la mûrir, donne-lui une forme, puis un visage. Le reste suivra, comme la lumière suit l'aube.` + note;
    } else {
      txt = `## Bien reçu\n\nTu m'as écrit : **${q ? q.slice(0, 160) : '(message vide)'}**\n\nDans Lilia Studio tu peux :\n\n- discuter avec **Claude, GPT, Gemini, Mistral** et 300+ modèles via OpenRouter\n- comparer 3 IA dans l'**Arène**\n- créer des pages et mini-jeux visibles en direct (**Artefact**)\n- construire un prompt solide en **5 rubriques**\n- dicter à la **voix** et suivre ton **budget**\n\n| Raccourci | Action |\n|---|---|\n| Ctrl K | Palette de commandes |\n| Ctrl N | Nouvelle session |\n| / | Tes prompts |` + note;
    }
    await stream(txt, push, signal, sp);
  }

  /* Meilleur modèle par défaut quand on ajoute une clé */
  async function bestModel(p) {
    const list = await listModels(p, true);
    const ids = list.map(m => m.id);
    const ver = id => +((id.match(/(\d+(?:\.\d+)?)/) || [])[1] || 0);
    const pick = re => ids.filter(id => re.test(id) && !/(preview|exp|lite|image|tts|live|audio|thinking|embed)/.test(id)).sort((a, b) => ver(b) - ver(a))[0];
    if (p === 'gemini') return pick(/^gemini-[\d.]+-flash$/) || pick(/flash/) || ids[0];
    if (p === 'anthropic') return pick(/sonnet/) || ids[0];
    if (p === 'openrouter') return ids.find(id => /:free$/.test(id) && /(gemini|llama|deepseek|mistral|qwen)/.test(id)) || ids.find(id => /:free$/.test(id)) || ids[0];
    if (p === 'mistral') return ids.includes('mistral-small-latest') ? 'mistral-small-latest' : ids[0];
    return ids[0];
  }

  window.AI = { PROVIDERS, listModels, chat, split, priceOf, bestModel };
})();
