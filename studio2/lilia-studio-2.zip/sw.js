/* Lilia Studio 2 — fonctionne hors ligne pour l'interface (les IA restent en ligne) */
const V = 'ls2-v2';
const FILES = ['./', 'index.html', 'css/app.css', 'js/store.js', 'js/providers.js', 'js/app.js', 'js/vendor/marked.min.js', 'js/vendor/purify.min.js', 'img/eye.png', 'img/icon-192.png',
  'fonts/space-grotesk-latin-500-normal.woff2', 'fonts/space-grotesk-latin-700-normal.woff2', 'fonts/instrument-serif-latin-400-italic.woff2', 'fonts/jetbrains-mono-latin-400-normal.woff2',
  'fonts/inter-latin-400-normal.woff2', 'fonts/inter-latin-500-normal.woff2', 'fonts/inter-latin-600-normal.woff2', 'fonts/inter-latin-700-normal.woff2'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(FILES))); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(x => x !== V).map(x => caches.delete(x))))); self.clients.claim(); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  // réseau d'abord (toujours la dernière version), cache si hors ligne
  e.respondWith(fetch(e.request).then(r => { const c = r.clone(); caches.open(V).then(x => x.put(e.request, c)); return r; }).catch(() => caches.match(e.request)));
});
